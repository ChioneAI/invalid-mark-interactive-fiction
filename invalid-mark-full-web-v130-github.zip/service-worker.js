const IMAGE_CACHE='invalid-mark-images-v133';
self.addEventListener('install',event=>event.waitUntil(self.skipWaiting()));
self.addEventListener('activate',event=>event.waitUntil(Promise.all([
 self.clients.claim(),
 caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('invalid-mark-images-')&&key!==IMAGE_CACHE).map(key=>caches.delete(key))))
])));
self.addEventListener('fetch',event=>{
 const request=event.request;
 if(request.method!=='GET'||request.destination!=='image')return;
 const url=new URL(request.url);
 if(url.origin!==self.location.origin)return;
 event.respondWith(caches.open(IMAGE_CACHE).then(async cache=>{
  const cached=await cache.match(request);
  const update=fetch(request).then(response=>{if(response&&response.ok)cache.put(request,response.clone());return response;}).catch(()=>null);
  if(cached){event.waitUntil(update);return cached;}
  return await update||Response.error();
 }));
});
