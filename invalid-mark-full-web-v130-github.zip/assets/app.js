window.INVALID_MARK_STORY.meta.version='1.34-full-web';
window.INVALID_MARK_STORY.meta.generated='2026-11-08';
(function(){
'use strict';

function supportsFlexGap(){
 var flex=document.createElement('div');
 flex.style.position='absolute';
 flex.style.visibility='hidden';
 flex.style.display='flex';
 flex.style.flexDirection='column';
 flex.style.rowGap='1px';
 flex.appendChild(document.createElement('div'));
 flex.appendChild(document.createElement('div'));
 document.body.appendChild(flex);
 var supported=flex.scrollHeight===1;
 flex.parentNode.removeChild(flex);
 return supported;
}
document.documentElement.classList.add(supportsFlexGap()?'supports-flex-gap':'no-flex-gap');

function setViewportHeight(){
 var height=window.innerHeight||document.documentElement.clientHeight||0;
 if(height>0)document.documentElement.style.setProperty('--app-height',height+'px');
}
function applyWindowInfo(info){
 if(!info)return;
 var root=document.documentElement;
 var safe=info.safeArea||{};
 var width=Number(info.windowWidth)||0;
 var height=Number(info.windowHeight)||0;
 var top=Math.max(0,Number(safe.top)||0);
 var left=Math.max(0,Number(safe.left)||0);
 var right=Math.max(0,width-(Number(safe.right)||width));
 var bottom=Math.max(0,height-(Number(safe.bottom)||height));
 root.style.setProperty('--xhs-safe-top',top+'px');
 root.style.setProperty('--xhs-safe-right',right+'px');
 root.style.setProperty('--xhs-safe-bottom',bottom+'px');
 root.style.setProperty('--xhs-safe-left',left+'px');
 var menuButtons=info.menuButtons||{};
 var menuItems=[menuButtons.me,menuButtons.share];
 var menuRight=0;
 if(width>0){
  menuItems.forEach(function(button){
   if(!button)return;
   var buttonLeft=Number(button.left);
   if(Number.isFinite(buttonLeft)&&buttonLeft>=width*.45)menuRight=Math.max(menuRight,width-buttonLeft+8);
  });
 }
 root.style.setProperty('--xhs-menu-right',Math.max(0,menuRight)+'px');
 if(height>0)root.style.setProperty('--app-height',height+'px');
}
function refreshWindowInfo(){
 setViewportHeight();
 var miniTool=window.xhs&&window.xhs.miniTool;
 if(!miniTool||typeof miniTool.getWindowInfo!=='function')return;
 try{Promise.resolve(miniTool.getWindowInfo()).then(applyWindowInfo).catch(function(){});}catch(error){}
}
refreshWindowInfo();
window.addEventListener('resize',refreshWindowInfo);
if(window.visualViewport&&typeof window.visualViewport.addEventListener==='function'){
 window.visualViewport.addEventListener('resize',setViewportHeight);
}

const D=window.INVALID_MARK_STORY;
D.nodes.T7={id:'T7',type:'scent',chapter:'11',scene:'葬礼厅堂外 · 烟尘中',prompt:'烟尘散去以后，一缕陌生的气息停在你的呼吸里。',notes:[{title:'海潮',body:'冷冽的潮气漫上来，是一片安静而辽阔的海。'},{title:'白百合',body:'海潮之后，白百合的香气被风托起，迎面而来。'},{title:'余烬',body:'最深处还藏着一点烧灼后的暖意，近似灰烬与火。'}],next:'ch11b_p01'};
D.nodes.MEMORY12={id:'MEMORY12',type:'memory',chapter:'12',prompt:'在你回答之前，一些画面重新浮现在眼前。',items:[{title:'宴会上的手',body:'在那场喧闹的宴会中，你选择越过人群，向他伸出手。',image:'assets/memory12/MEMORY12_01_BANQUET_HAND.webp'},{title:'一纸委托',body:'那些难以理解的条款，后来才显出被小心藏起的在意。',image:'assets/memory12/MEMORY12_02_CONTRACT.webp'},{title:'标记无效',body:'你们第一次意识到，标记无法证明归属，失效也不等于失去。',image:'assets/memory12/MEMORY12_03_INVALID_MARK_v3.webp'},{title:'你说爱我',body:'高热拖过十二个昼夜。标记没有留下，只有那句爱，被他一遍遍记住。',image:'assets/memory12/MEMORY12_04_TWELVE_DAYS.webp'}],next:'E4'};
D.nodes.IFGALLERY={id:'IFGALLERY',type:'gallery',chapter:'IF',scene:'Mo Art Studio · 创作室',title:'在忘记以前',prompt:'满室画作都指向同一个陌生的人。祁煜不记得她，却认得自己的笔触。',items:[{title:'灯下的第一次',body:'金色灯影里，她朝他伸出手。',image:'assets/ifgallery/IFGALLERY_01_FIRST_LIGHT.webp'},{title:'有她的午后',body:'窗光落在空椅和未干的颜料上，这是一个有她的午后。',image:'assets/ifgallery/IFGALLERY_02_AFTERNOON.webp'},{title:'雪落之前',body:'他反复描摹同一段相遇，在世界忘记她以前，替自己留下一条回去的路。',image:'assets/ifgallery/IFGALLERY_03_BEFORE_SNOW.webp'}],next:'ifa_p09'};
[
 {id:'ifa_p01',src:[615,620],text:['你失踪于一个荒芜的冬夜。','你的名字、身份与留下的一切痕迹，都如同被投入烈火的雪片，转瞬消弭。你仿佛人间蒸发，甚至连一张可供凭吊的照片都未曾留下。','你是一个意外来到ABO世界的普通人。正如你突如其来地降临于这片天地，你的离去也同样猝不及防。','为了维持平衡，世界意志潜移默化地模糊了所有人的记忆。与你接触越深，遗忘便来得越快。','即使你曾以为那些痕迹会永远留存，可人力毕竟太过渺小，世事运转也从不因人的意志转移。'],next:'ifa_p02'},
 {id:'ifa_p02',src:[621,625],text:['唯有祁煜。','祁煜最大的自由意志，便是记住你。','记住你，并不是一件幸福的事。它带来无边无尽的痛苦，也是一场与世界意志的对抗。每一次回忆起曾经的幸福，都像是在伤口上撒盐。','从前的欢笑变得苦涩，快乐的画面变成刺穿心脏的箭矢。可祁煜仍近乎固执地将它当成爱。','这个强大的Alpha，究其一生好像都在寻觅同一个问题——爱是什么？'],next:'ifa_p03'},
 {id:'ifa_p03',src:[626,632],text:['ABO世界的婚姻反面案例，总在讲Omega失去Alpha后，带着终身标记却再无信息素纾解。却很少有人询问，一个失去伴侣的Alpha会怎么样。','人们理所当然地认为，Alpha只需要再选择下一个伴侣即可。这是性别带来的畸形特权。','可是，本就如此、一直如此、从来如此……便是对吗？','至少这套通行准则，在患有信息素应激症的祁煜面前完全行不通。','正如祁煜爱上你时，不是因为信息素驱使，而是因为爱本身，因为心理上对你的亲近与依赖。你离去之后，他也不可能因为信息素或人造香精，再爱上另一个人。'],next:'ifa_p04'},
 {id:'ifa_p04',src:[633,640],text:['祁煜将大量时间投入创作。他日以继夜，用尽毕生所学的技法，寻尽罕见的色彩，勾描出一个你，又勾描出无数个你。','原本偏好抽象色彩的祁大艺术家一反常态，画起写实的素描与油画，恨不得留下每一帧、每一瞬你的表情。','再迟一点，再晚一点，他便要忘记你了。','祁煜不想忘记。他甚至后悔，当初为什么没有让监控覆盖整个Mo Art Studio，乃至整个白沙湾。','即使影像也会在你离去后逐渐失效，变成卡顿的白点黑屏，他还是想竭尽全力，再多挽留些什么。','他想挽留你的笑与泪，挽留初见的宴席，挽留你挽住他臂膀的瞬间，也挽留无人知晓的休息室里，那个仓促的吻。'],next:'ifa_p05'},
 {id:'ifa_p05',src:[641,645],text:['祁煜也想回到那场舞会，回到你左脚绊右脚的夜晚。你不好意思地吐吐舌头，却在下一秒继续踩上他的脚。','直到将这些景象都变为画作，他才意识到，你们原来拥有过这么多幸福的回忆。意识到它们曾经存在，他便好像不再那么痛苦。','这个曾满腔复仇怒火的Alpha，在你的影响下，也学会了释然与放手，任由长风呼啸而过，任由一切离开。','只要记得你，就足够了。','祁煜谋得了心灵的一方平静，可他的身体却不愿安息。它叫嚣着呼唤你的名字，寻觅那缕若有若无的晚玉香气。'],next:'ifa_p06'},
 {id:'ifa_p06',src:[646,652],text:['祁煜的信息素应激症愈演愈烈。严重时，他几乎会对所有气味产生抵触，甚至包括自己的信息素。','只要嗅到灼热的火焰、广袤的海洋、如大雪般死寂的灰烬，他便会想起你。','祁煜抵触所有的气味。','唐知理为此愁得头发都快掉光了。Alpha进入医疗室的频率越来越高，应激的范围也越来越广。','一个Alpha，已经无法在ABO世界正常生活了。这听起来像一个荒谬的笑话。','唐知理联系各大医院，竭尽全力寻找不会产生耐药性的抑制剂或舒缓剂，但收效甚微。'],next:'ifa_p07'},
 {id:'ifa_p07',src:[653,658],text:['最后，唐知理只好强制将祁煜送进全隔离病房。','“祖宗啊，你用了二十多年的抑制剂，怎么说失效就失效了呢？”','祁煜听见这句话，忽地一怔。','对啊。为什么抑制剂会不再起效？','为什么我会开始讨厌自己的信息素，讨厌所有的气味，讨厌这个世界？','窗外枝叶零落，寒风萧瑟。残叶被长风吹得摇摆不定，最终飘然落下。'],next:'ifa_p08'},
 {id:'ifa_p08',src:[659,663],text:['即使全隔离病房是一个安全的乌托邦，祁煜也并不喜欢。这里太过冰冷，一切都是零度，是苍白的，像一个荒芜的冬天。','祁煜并不喜欢这样的冬天。','于是在冬天彻底到来以前，他离开病房，回到白沙湾，回到Mo Art Studio。','阔别几月，再次回到自己的住所，祁煜没什么特别的感受。白沙湾远离人烟，与冰冷病房的区别似乎也不算太大。','回到这里的第一时间，他推开创作室的门，看见满画室的画作挤挤挨挨，勾描着同一个女人。'],next:'IFGALLERY'},
 {id:'ifa_p09',src:[664,675],text:['她是谁？','祁煜可以确信自己并不认识她。他搜刮脑海中的每一处，也找不到任何一点关于这个女孩的记忆。','可为什么在看到这些画作时，他会感到如此熟悉，仿佛似曾相识？','他自嘲自己被医院关得太久，脑子出了毛病。待走到画前，才发觉边缘写着一行行熟悉的小字。','“她失踪于一个冬夜，你是这世上最后一个记得她的人。”','“她不是Beta，她是一个不属于ABO世界的普通人。”','“她不擅长跳舞，参加舞会时容易踩到你的脚。”','“她身上有一股淡淡的，晚玉般的清香。”','“她会唤你，先生。”','“她是你的爱人。”','“不要忘记她的名字。”','“不要忘记。”'],next:'ifa_p10'},
 {id:'ifa_p10',src:[676,685],text:['熟悉的文字如同游鱼漂浮在眼前，勾勒出一个荒诞的志怪故事。祁煜身处其中，难辨真伪。','窗外骤起风雪，百年难遇的暴雪顷刻将白沙湾染成苍茫一片。','祁煜望向雪色，心脏却浮现出一个空洞，冽冽刮过寒风。直到此刻，他终于知晓自己在思念谁。','他并不只感到难过，也感到幸运。那些画作令有关你的记忆一一复苏。当整个世界都已遗忘你时，只有祁煜想起了你。','祁煜推开门，向雪原与一望无际的荒芜走去。他依稀记得，你便是消失在这样的冬夜。','他一直向前，直到周遭变得空空荡荡。寒风刮过皮肤，他仍挣扎着继续走，想寻找抵挡风雪的地方，又或是同你一样，消弭在风雪中。','大雪层层叠叠，掩埋了他的脚印。','名利似汤浇瑞雪，荣华如秉烛当风……可怜人一枕南柯梦。'],next:'ifa_p11'},
 {id:'ifa_p11',src:[686,689],text:['你的卧室一片漆黑，只有窗外透进一点暗淡的雪光。','直到看见窗沿积起的薄雪，你才发觉冬天已经到了。初雪落下，气温骤降，床榻也显得冰凉。','一个人为工作奔波，难免会觉得孤独落寞。幸好你还算积极乐观，总愿意为一些虚无缥缈的美好停下脚步。','于是你掀开被褥，披上外套，换上长靴，决定去赏一场临空市难得一见的大雪。'],next:'ifa_p12'},
 {id:'ifa_p12',src:[690,693],text:['你走在昏黄的路灯下，看着雪花落上透明伞面。大半夜跑出来赏雪听起来不太正常，可你却觉得这样的行为纯粹极了。','此刻你不用在人类社会伪装成大人，不用穿上坚硬的铠甲，小心翼翼、察言观色。大自然并不需要你收敛脾性，成为一颗勤奋工作的螺丝钉。','或许人类生来便是为了寻觅自己缺失的一部分。触景生情之下，你总觉得自己一直在等待一个回音。','你在等候自己的心声由远至近传回，等候一个人敲开心扉，探秘你深邃而又稍显怪异的内心世界。','你在临空的初雪天，遇见了一个人。'],next:'ifa_p13'},
 {id:'ifa_p13',src:[694,698],text:['他没有打伞，精致的手工西装覆满白雪，连眼睫与发梢也沾染了点点雪白。','他回转过身，望见你时，眼底猝然浮起潋滟的笑意。','“先生……？”你迟疑着，低声唤他，“您需要帮助吗？”','男人向你迈了半步，又担心贸然接近会令你害怕，于是停在昏黄路灯下，让你看清他轮廓深邃的眉眼与一头紫色鬈发。','他遥遥望着你，嘴角荡开一点清浅笑意：“如果可以的话，你能告诉我，这是哪儿吗？”'],next:'ifa_p14'},
 {id:'ifa_p14',src:[699,705],text:['你从大雪天里捡回来一个陌生的男人。','你不得不承认，这个世界就是一个看脸的世界。如果换作另一个举止鬼祟的男人，你绝不会多管闲事地询问半句。','可偏偏这个男人长相昳丽、举止绅士。他与你同撑一把伞时，雪花落满他的大半个肩头，而你被全然护在伞下。','他的一言一行都充满对异性的尊重与对帮助者的感激，始终保持着恰到好处的距离。','在询问你的名字以前，他先告诉你他的名讳：“祁煜。”','听见这个名字，你几乎下意识地调侃：“你这个人，确实很像一场奇遇。”'],next:'ifa_p15'},
 {id:'ifa_p15',src:[706,709],text:['说完这话，你却愣在原地。似曾相识的感觉又一次击中你，让你疑惑、迟疑，甚至还有些怀念。','祁煜看出你的若有所思，笑着解释：“其实是因为你，让这场平常的相遇变得有意义，让它足以被称作奇遇。”','你意识到这个男人无比聪明又有心机，简简单单一句话，也能说得这样漂亮熨帖，让听者心中蕴着暖意。','紧接着你便得知，祁煜迷了路，无家可归，也无处可去。'],next:'ifa_p16'},
 {id:'ifa_p16',src:[710,714],text:['你被他那副楚楚可怜的样子蛊惑，头脑一热，大言不惭地承诺：“没事，别担心。你若不嫌弃，在你找到去处之前，便先住我家。”','话一出口，你才意识到孤男寡女共处一室有多不妥。可你已经在祁煜面前放出话来，揽下了这个瓷器活。','而祁煜笑意盈盈，将你窘迫的神态烙进眼中。','他说：“好呀。”'],next:'ifa_p17'},
 {id:'ifa_p17',src:[715,717],text:['窗外冷风回旋，将遥远的残叶卷至窗前。','山穷水尽之时，好像总会有一线生机；即使绝处，也能逢生。','或许你我无论遭逢怎样的境遇，无论做出怎样的选择……兜兜转转，也总会重逢吧？'],next:null,ending:'冬夜'}
].forEach(function(node){D.nodes[node.id]=Object.assign({type:'page',chapter:'IF',chars:node.text.join('').length},node);});
let N=D.nodes;
const SAVEKEY='invalid_mark_touch_winter_v117';
const LEGACY_SAVEKEY='invalid_mark_scent_gallery_v116';
const OLDER_SAVEKEY='invalid_mark_scent_memory_v115';
const OLDEST_SAVEKEY='invalid_mark_case_archive_v114';
const CONTRACT_SAVEKEY='invalid_mark_contract_chat_v112';
const EARLIEST_SAVEKEY='invalid_mark_navigation_themes_v19';
const FIRST_SAVEKEY='invalid_mark_full_backgrounds_v18';
const $=s=>document.querySelector(s);
const esc=x=>String(x==null?'':x).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
function store(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true;}catch(e){return false;}}
function load(k){try{return JSON.parse(localStorage.getItem(k)||'null');}catch(e){return null;}}
const CH={};
function buildChapters(){
 for(const n of Object.keys(N).map(k=>N[k]))if(n.type==='chapter')CH[n.chapter]={title:n.title,pages:[],index:{}};
 for(const id of Object.keys(N)){const n=N[id];if(n.type==='page'){if(!CH[n.chapter])CH[n.chapter]={title:'',pages:[],index:{}};CH[n.chapter].pages.push(id);}}
 for(const ch in CH)CH[ch].pages.forEach((id,i)=>CH[ch].index[id]=i);
}
buildChapters();
function fresh(){return {cur:D.meta.start||'CH01',mode:'read',theme:'dark',textSize:0,musicMuted:false,autoPlay:false,flags:{},stack:[],tries:0,started:false,beat:0,ifUnlocked:false,completedMain:false,rollbackUnlocked:true,visited:{},endings:{}};}
let S=Object.assign(fresh(),load(SAVEKEY)||load(LEGACY_SAVEKEY)||load(OLDER_SAVEKEY)||load(OLDEST_SAVEKEY)||load(CONTRACT_SAVEKEY)||load(EARLIEST_SAVEKEY)||load(FIRST_SAVEKEY)||{});
if(S.ifUnlocked)S.completedMain=true;
if(!S.endings||typeof S.endings!=='object')S.endings={};
if(S.endings.TRUE_LONGEVITY){S.completedMain=true;S.ifUnlocked=true;}
S.rollbackUnlocked=true;
if([-2,-1,0,1,2].indexOf(Number(S.textSize))===-1)S.textSize=0;else S.textSize=Number(S.textSize);
if(!N[S.cur])S=fresh();
let typing=null, toastTimer=null, autoTimer=null;
const stage=$('#stage'), foot=$('#foot'), footHint=$('#footHint'), ov=$('#ov'), ovIn=$('#ovIn');
const ENDING_CATALOG=[
 {id:'END_A',type:'支线结局',title:'未完成的委托',mood:'错过 · 遗憾',target:'END_A',image:'assets/endings/ending-a-unfinished-commission.webp'},
 {id:'END_C',type:'支线结局',title:'未出席的葬礼',mood:'错过 · 勇气',target:'END_C',image:'assets/endings/ending-c-funeral-absence.webp'},
 {id:'END_D',type:'支线结局',title:'永远',mood:'温柔 · 自由',target:'END_D',image:'assets/endings/ending-d-eternal-now.webp'},
 {id:'TRUE_LONGEVITY',type:'主线结局',title:'长青',mood:'爱不因标记而存在',target:'ch13a_p03',image:'assets/endings/ending-true-evergreen.webp'},
 {id:'IF_WINTER',type:'IF 结局',title:'冬夜',mood:'当记忆穿过冬夜',target:'ifa_p11',image:'assets/endings/ending-if-winter.webp'}
];
function applyTheme(){
 const theme=S.theme==='light'?'light':'dark';S.theme=theme;document.body.dataset.theme=theme;
 const meta=$('#themeColor');if(meta)meta.setAttribute('content',theme==='light'?'#f3f1ec':'#0c0a0e');
 const label=theme==='light'?'切换为深色主题':'切换为浅色主题';
 ['#btnTheme','#btnThemeStart'].forEach(sel=>{const b=$(sel);if(b){b.title=label;b.setAttribute('aria-label',label);}});
}
function toggleTheme(){S.theme=S.theme==='light'?'dark':'light';applyTheme();save();}
function applyTextSize(){
 const labels={'-2':'极小字号','-1':'较小字号','0':'默认字号','1':'较大字号','2':'最大字号'};
 const marks={'-2':'A--','-1':'A-','0':'Aa','1':'A+','2':'A++'};
 const size=[-2,-1,0,1,2].indexOf(Number(S.textSize))===-1?0:Number(S.textSize);
 S.textSize=size;document.body.setAttribute('data-text-size',String(size));
 const button=$('#btnText');if(button){button.textContent=marks[String(size)];button.title='调整文字大小 · '+labels[String(size)];button.setAttribute('aria-label','调整文字大小，当前'+labels[String(size)]);}
}
function directoryUnlocked(){return true;}
const CHAPTER_FEATURES={
 '01':['ending'],'02':['game'],'04':['game'],'05':['game'],'09':['ending','game'],'11':['game'],'12':['ending','game'],'IF':['game']
};
function renderChapterList(){
 const ids=['CH01','CH02','CH03','CH04','CH05','CH06','CH07','CH08','CH09','CH10','CH11','CH12','CH13','CHIF'];
 const open=directoryUnlocked();
 const note='全部章节已开放，可随时跳转查看；当前进度仍会自动保存。';
 $('#chapterList').innerHTML='<div class="chapter-access-note '+(open?'open':'locked')+'">'+note+'</div>'+ids.map(id=>{const n=N[id],parts=(n.title||'').split('｜'),current=S.cur===id||N[S.cur]&&N[S.cur].chapter===n.chapter,seen=!!(S.visited[id]||Object.keys(S.visited).some(k=>N[k]&&N[k].chapter===n.chapter)),locked=false,features=CHAPTER_FEATURES[n.chapter]||[],tags=features.map(feature=>'<span class="chapter-tag">'+(feature==='ending'?'【结局选择】':'【互动游戏】')+'</span>').join(''),mark=current?'当前进度':seen?'已读':'跳转';return '<button class="chapter-link '+(current?'current ':'')+'" data-chapter-id="'+esc(id)+'"><span class="no">'+esc(parts[0]||n.chapter)+'</span><span class="chapter-copy"><span class="name">'+esc(parts[1]||n.title)+'</span><span class="chapter-tags">'+tags+'</span></span><span class="mark">'+mark+'</span></button>';}).join('');
}
function openContents(){renderChapterList();$('#chapterDrawer').classList.add('on');$('#chapterDrawer').setAttribute('aria-hidden','false');$('#navScrim').classList.add('on');}
function closeContents(){$('#chapterDrawer').classList.remove('on');$('#chapterDrawer').setAttribute('aria-hidden','true');$('#navScrim').classList.remove('on');}
function renderEndingArchive(){
 let unlocked=0;$('#endingGrid').innerHTML=ENDING_CATALOG.map((item,i)=>{const open=!!S.endings[item.id];if(open)unlocked++;return '<button class="ending-card '+(open?'':'locked')+'" style="background-image:url(&quot;'+esc(item.image)+'&quot;)" '+(open?'data-ending-id="'+esc(item.id)+'"':'disabled')+'><span class="type">'+(open?esc(item.type):'ENDING '+String(i+1).padStart(2,'0'))+'</span><h3>'+(open?esc(item.title):'未解锁结局')+'</h3><p>'+(open?esc(item.mood):'继续故事，寻找这一种可能。')+'</p></button>';}).join('');
 $('#endingCount').textContent='已收录 '+unlocked+' / '+ENDING_CATALOG.length+' · 自由回档可用';
}
function openEndings(){renderEndingArchive();$('#endingArchive').classList.add('on');$('#endingArchive').setAttribute('aria-hidden','false');}
function closeEndings(){$('#endingArchive').classList.remove('on');$('#endingArchive').setAttribute('aria-hidden','true');}
function unlockEnding(id){if(!id)return;if(!S.endings[id]){S.endings[id]=true;save();}}
let saveQueued=false;
function save(){
 if(!saveQueued){saveQueued=true;requestAnimationFrame(()=>{saveQueued=false;store(SAVEKEY,S);});}
 queueBridgeSave();
}
let bridgeSaveTimer=null;
function queueBridgeSave(){clearTimeout(bridgeSaveTimer);bridgeSaveTimer=setTimeout(()=>{var bridge=window.xhs&&window.xhs.miniTool;if(bridge&&typeof bridge.setStorage==='function'){try{Promise.resolve(bridge.setStorage({key:SAVEKEY,data:JSON.stringify(S)})).catch(function(){});}catch(e){}}},120);}
function inform(msg){const el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2400);}
function labelChapter(n){return (CH[n.chapter]&&CH[n.chapter].title)||('章节 '+(n.chapter||''));}
function showBar(n){let lab=labelChapter(n);$('#barChap').textContent=lab.replace('｜',' · ');let c=CH[n.chapter],i=c&&c.index[n.id],p=Number.isInteger(i)&&c.pages.length?Math.round(100*(i+1)/c.pages.length):0;$('#barProg').style.width=Math.max(3,Math.min(100,p))+'%';}
function clearAutoTimer(){if(autoTimer){clearTimeout(autoTimer);autoTimer=null;}}
function resetTyping(){if(typing){clearInterval(typing.timer);typing=null;}}
function finishTyping(){if(!typing)return;clearInterval(typing.timer);typing.el.textContent=typing.target;typing=null;}
function startTyping(el,str){resetTyping();if(window.matchMedia('(prefers-reduced-motion: reduce)').matches){el.textContent=str;return;}el.textContent='';typing={el,target:str,timer:null};let pos=0;typing.timer=setInterval(()=>{pos+=2;if(pos>=str.length)finishTyping();else el.textContent=str.slice(0,pos);},15);}
function go(id,push=true){if(!N[id]){inform('节点不存在：'+id);return;}clearAutoTimer();resetTyping();closeOv();if(push&&S.cur!==id&&N[S.cur])S.stack.push(S.cur);if(S.stack.length>500)S.stack.shift();S.cur=id;S.beat=0;S.visited[id]=(S.visited[id]||0)+1;render();save();}
function canBack(){
 const n=N[S.cur];
 return !!(S.mode==='gal'&&n&&n.type==='page'&&S.beat>0||S.stack.length);
}
function back(){
 resetTyping();const n=N[S.cur];
 if(S.mode==='gal'&&n&&n.type==='page'&&S.beat>0){S.beat--;render();save();return;}
 if(canBack()){go(S.stack.pop(),false);return;}
 inform('已经是故事起点');
}
function backToChoice(){for(let i=S.stack.length-1;i>=0;i--){const id=S.stack[i],n=N[id];if(n&&(n.type==='choice'||n.type==='keypad')){S.stack=S.stack.slice(0,i);go(id,false);return;}}inform('暂无可返回的选择');}
function restart(mode=S.mode){S=Object.assign(fresh(),{mode,theme:S.theme,textSize:S.textSize,musicMuted:S.musicMuted,started:true,ifUnlocked:S.ifUnlocked,completedMain:S.completedMain,rollbackUnlocked:S.rollbackUnlocked,endings:Object.assign({},S.endings)});applyTheme();applyTextSize();updateMusicButton();$('#start').style.display='none';go(D.meta.start||'CH01',false);}
function home(){clearAutoTimer();resetTyping();closeOv();refreshStart();$('#start').style.display='flex';}
function closeOv(){ov.classList.remove('on','rollback-on','ending-on');ovIn.className='in';ovIn.innerHTML='';}
function echoFor(n){if(!n.echoes)return '';for(const key in n.echoes){let v=n.echoes[key][S.flags[key]];if(v)return v;}return '';}
const DISPLAY_SOURCE={};
function splitDisplayLine(line){
 const value=String(line||'');if(value.length<=96)return[value];
 const sentences=value.match(/[^。！？；]+[。！？；”』】]?|.+$/g)||[value],parts=[];let current='';
 sentences.forEach(sentence=>{if(current&&current.length+sentence.length>96){parts.push(current);current='';}current+=sentence;});
 if(current)parts.push(current);return parts;
}
function textParts(n){
 const source=(n.text||[]).slice(),echo=echoFor(n);if(echo)source.push(echo);const parts=[];
 source.forEach(line=>splitDisplayLine(line).forEach(part=>{DISPLAY_SOURCE[n.id+'|'+part]=line;parts.push(part);}));return parts;
}
const VISUAL_OVERRIDES={
 ch01a_p01:{scene:'banquet',location:'宴会厅 · 夜',actor:'neutral'},
 ch01a_p02:{scene:'banquet',location:'宴会厅 · 夜',actor:'neutral'},
 ch01a_p03:{scene:'banquet',location:'宴会厅 · 夜',actor:'neutral'},
 ch01a_p04:{scene:'banquet',location:'宴会厅 · 夜',actor:'strain',sense:true},
 ch01b_p01:{scene:'banquet',location:'宴会厅 · 夜',actor:'strain'},
 ch01c_p01:{scene:'vip',location:'贵宾休息室 · 夜',actor:'strain',sense:true},
 ch01c_p02:{scene:'vip',location:'贵宾休息室 · 夜',actor:'strain',sense:true},
 ch01c_p03:{scene:'vip',location:'贵宾休息室 · 夜',actor:'shock'},
 ch01c_p04:{scene:'vip',location:'贵宾休息室 · 夜',actor:'shock'}
};
const BEAT_OVERRIDES={
 ch01a_p02:{2:{kind:'ambient',speaker:'宾客私语'},3:{kind:'ambient',speaker:'宾客'},4:{kind:'ambient',speaker:'宾客'},5:{kind:'ambient',speaker:'宾客'},6:{kind:'ambient',speaker:'宾客'},7:{kind:'dialogue',speaker:'陈总'}},
 ch01a_p03:{0:{kind:'dialogue',speaker:'祁煜'},3:{kind:'thought',speaker:'心声'},4:{kind:'dialogue',speaker:'陈总'}},
 ch01a_p04:{2:{kind:'dialogue',speaker:'陈总'}},
 ch01b_p01:{1:{kind:'dialogue',speaker:'你'},3:{kind:'thought',speaker:'心声'},4:{kind:'dialogue',speaker:'祁煜'}},
 ch01c_p04:{0:{kind:'dialogue',speaker:'你'},1:{kind:'dialogue',speaker:'你'},3:{kind:'dialogue',speaker:'祁煜'}}
};
Object.assign(BEAT_OVERRIDES,{
 ch02a_p02:{1:{kind:'ambient',speaker:'声响'}},ch02a_p04:{1:{kind:'dialogue',speaker:'你'}},ch02a_p07:{5:{kind:'ambient',speaker:'终端'}},ch02a_p09:{0:{kind:'narration',speaker:'旁白'}},ch02b_p01:{1:{kind:'thought',speaker:'心声'}},
 ch03a_p02:{2:{kind:'ambient',speaker:'声响'},4:{kind:'dialogue',speaker:'祁煜'}},ch03a_p03:{3:{kind:'dialogue',speaker:'你'},4:{kind:'dialogue',speaker:'你'},5:{kind:'dialogue',speaker:'祁煜'}},ch03a_p06:{2:{kind:'dialogue',speaker:'祁煜'}},ch03a_p07:{0:{kind:'dialogue',speaker:'祁煜'}},ch03c_p01:{0:{kind:'dialogue',speaker:'你'},1:{kind:'dialogue',speaker:'祁煜'},2:{kind:'thought',speaker:'心声'}},
 ch04a_p01:{1:{kind:'dialogue',speaker:'你'}},ch04a_p02:{0:{kind:'dialogue',speaker:'唐知理'},1:{kind:'dialogue',speaker:'你'}},ch04a_p03:{4:{kind:'dialogue',speaker:'祁煜'}},ch04a_p04:{3:{kind:'dialogue',speaker:'祁煜'}},ch04a_p06:{3:{kind:'dialogue',speaker:'宾客'}},ch04a_p08:{0:{kind:'dialogue',speaker:'陌生男子'}},ch04b_p01:{0:{kind:'dialogue',speaker:'你'}},ch04c_p01:{2:{kind:'ambient',speaker:'声响'},6:{kind:'ambient',speaker:'宾客'},7:{kind:'ambient',speaker:'宾客'}},ch04c_p02:{0:{kind:'ambient',speaker:'宾客'},1:{kind:'ambient',speaker:'宾客'},2:{kind:'ambient',speaker:'宾客'},4:{kind:'narration',speaker:'旁白'}},ch04c_p05:{1:{kind:'dialogue',speaker:'祁煜'}},ch04c_p06:{6:{kind:'dialogue',speaker:'祁煜'}},
 ch05a_p02:{1:{kind:'dialogue',speaker:'你'},2:{kind:'dialogue',speaker:'你'},3:{kind:'dialogue',speaker:'唐知理'}},ch05a_p03:{0:{kind:'dialogue',speaker:'唐知理'},1:{kind:'dialogue',speaker:'你'},2:{kind:'dialogue',speaker:'唐知理'}},ch05a_p04:{1:{kind:'dialogue',speaker:'你'}},ch05a_p05:{1:{kind:'dialogue',speaker:'唐知理'}},ch05b_p04:{2:{kind:'ambient',speaker:'声响'},4:{kind:'dialogue',speaker:'祁煜'}},ch05b_p07:{4:{kind:'dialogue',speaker:'你'}},
 ch06a_p01:{2:{kind:'dialogue',speaker:'祁煜'},4:{kind:'dialogue',speaker:'祁煜'}},ch06a_p02:{2:{kind:'dialogue',speaker:'你'},4:{kind:'ambient',speaker:'心跳'}},ch06a_p05:{2:{kind:'dialogue',speaker:'祁煜'}},ch07a_p04:{4:{kind:'dialogue',speaker:'你'}},
 ch08a_p01:{0:{kind:'dialogue',speaker:'你'},3:{kind:'ambient',speaker:'终端'}},ch08a_p03:{0:{kind:'ambient',speaker:'声响'},3:{kind:'dialogue',speaker:'祁煜'}},ch08a_p04:{0:{kind:'dialogue',speaker:'你'},1:{kind:'dialogue',speaker:'你'},2:{kind:'dialogue',speaker:'祁煜'},3:{kind:'dialogue',speaker:'祁煜'}},ch08a_p05:{0:{kind:'dialogue',speaker:'祁煜'},1:{kind:'dialogue',speaker:'祁煜'},2:{kind:'dialogue',speaker:'祁煜'}},ch08a_p07:{2:{kind:'dialogue',speaker:'祁煜'}},ch08a_p08:{2:{kind:'dialogue',speaker:'祁煜'}},ch08a_p09:{0:{kind:'dialogue',speaker:'你'},1:{kind:'dialogue',speaker:'祁煜'},3:{kind:'dialogue',speaker:'你'},4:{kind:'dialogue',speaker:'你'},5:{kind:'dialogue',speaker:'你'}},ch08a_p10:{0:{kind:'dialogue',speaker:'祁煜'},1:{kind:'dialogue',speaker:'祁煜'},2:{kind:'dialogue',speaker:'你'},4:{kind:'dialogue',speaker:'祁煜'}},ch08a_p11:{3:{kind:'dialogue',speaker:'祁煜'},4:{kind:'dialogue',speaker:'祁煜'},5:{kind:'dialogue',speaker:'祁煜'}},ch08a_p12:{0:{kind:'dialogue',speaker:'祁煜'},1:{kind:'dialogue',speaker:'祁煜'}},
 ch09a_p09:{2:{kind:'dialogue',speaker:'祁煜'}},ch09a_p10:{0:{kind:'dialogue',speaker:'祁煜'},1:{kind:'dialogue',speaker:'你'},2:{kind:'dialogue',speaker:'祁煜'}},ch09c_p01:{0:{kind:'dialogue',speaker:'你'}},ch09c_p02:{1:{kind:'dialogue',speaker:'你'},2:{kind:'dialogue',speaker:'你'}},ch09c_p03:{0:{kind:'narration',speaker:'旁白'}},ch09c_p04:{2:{kind:'dialogue',speaker:'祁煜'}},ch09c_p05:{1:{kind:'dialogue',speaker:'祁煜'},2:{kind:'dialogue',speaker:'祁煜'}},ch09c_p06:{3:{kind:'dialogue',speaker:'你'}},ch09c_p07:{0:{kind:'dialogue',speaker:'你'}},
 ch10a_p11:{3:{kind:'dialogue',speaker:'祁煜'}},ch10a_p12:{0:{kind:'dialogue',speaker:'祁煜'},1:{kind:'dialogue',speaker:'祁煜'},3:{kind:'dialogue',speaker:'祁煜'},4:{kind:'dialogue',speaker:'祁煜'},5:{kind:'dialogue',speaker:'祁煜'},6:{kind:'dialogue',speaker:'祁煜'},7:{kind:'dialogue',speaker:'祁煜'}},ch10a_p13:{3:{kind:'dialogue',speaker:'祁煜'}},ch10a_p14:{1:{kind:'dialogue',speaker:'祁煜'}},
 ch11a_p01:{1:{kind:'dialogue',speaker:'陈兴业'},2:{kind:'dialogue',speaker:'陈兴业'},3:{kind:'dialogue',speaker:'陈兴业'}},ch11a_p02:{0:{kind:'dialogue',speaker:'祁煜'},3:{kind:'dialogue',speaker:'陈兴业'}},ch11a_p03:{2:{kind:'ambient',speaker:'爆炸'}},ch11b_p01:{3:{kind:'dialogue',speaker:'祁煜'}},ch11b_p02:{3:{kind:'dialogue',speaker:'医生'},4:{kind:'dialogue',speaker:'医生'}},ch11b_p03:{0:{kind:'dialogue',speaker:'医生'}},ch11b_p04:{1:{kind:'dialogue',speaker:'祁煜'},3:{kind:'dialogue',speaker:'医生'},4:{kind:'dialogue',speaker:'祁煜'}},ch11b_p05:{1:{kind:'dialogue',speaker:'祁煜'},2:{kind:'dialogue',speaker:'医生'}},
 ch12a_p01:{1:{kind:'dialogue',speaker:'祁煜'},4:{kind:'dialogue',speaker:'祁煜'},5:{kind:'dialogue',speaker:'祁煜'}},ch12a_p02:{3:{kind:'dialogue',speaker:'你'},5:{kind:'dialogue',speaker:'祁煜'},6:{kind:'dialogue',speaker:'祁煜'},7:{kind:'dialogue',speaker:'祁煜'},8:{kind:'dialogue',speaker:'祁煜'}},ch12a_p03:{3:{kind:'dialogue',speaker:'祁煜'},4:{kind:'dialogue',speaker:'祁煜'}},ch12b_p01:{0:{kind:'dialogue',speaker:'你'},1:{kind:'dialogue',speaker:'你'},5:{kind:'dialogue',speaker:'你'}},ch12b_p02:{1:{kind:'dialogue',speaker:'你'},2:{kind:'dialogue',speaker:'你'}},
 ch13a_p02:{0:{kind:'dialogue',speaker:'祁煜'},1:{kind:'dialogue',speaker:'你'},2:{kind:'dialogue',speaker:'祁煜'},3:{kind:'dialogue',speaker:'祁煜'}},
 ifa_p07:{1:{kind:'dialogue',speaker:'唐知理'},3:{kind:'thought',speaker:'祁煜'},4:{kind:'thought',speaker:'祁煜'}},ifa_p09:{4:{kind:'artifact',speaker:'画中题字'},5:{kind:'artifact',speaker:'画中题字'},6:{kind:'artifact',speaker:'画中题字'},7:{kind:'artifact',speaker:'画中题字'},8:{kind:'artifact',speaker:'画中题字'},9:{kind:'artifact',speaker:'画中题字'},10:{kind:'artifact',speaker:'画中题字'},11:{kind:'artifact',speaker:'画中题字'}},ifa_p13:{2:{kind:'dialogue',speaker:'你'},4:{kind:'dialogue',speaker:'祁煜'}},ifa_p14:{4:{kind:'dialogue',speaker:'祁煜'},5:{kind:'dialogue',speaker:'你'}},ifa_p15:{1:{kind:'dialogue',speaker:'祁煜'}},ifa_p16:{0:{kind:'dialogue',speaker:'你'},3:{kind:'dialogue',speaker:'祁煜'}}
});
const SCENE_RANGES=[
 [/^ch02a_p0[1-3]$/,'vip','贵宾休息室 · 夜','formal','neutral'],[/^ch02a_p0[4-6]$/,'car','车内 · 夜','formal','neutral'],[/^ch02(?:a_p0[7-9]|b_p01)$/,'guest','Mo Art Studio · 客卧','formal','neutral'],
 [/^ch03a_p01$/,'living-day','Mo Art Studio · 客厅','home','smile'],[/^ch03a_p02$/,'studio-day','Mo Art Studio · 画室','home','neutral'],[/^ch03/,'dining-night','Mo Art Studio · 餐厅','home','smile'],
 [/^ch04a_p0[1-5]$/,'living-day','Mo Art Studio · 客厅','formal','smile'],[/^ch04a_p06$/,'dance','宴会厅 · 舞池','formal','smile'],[/^ch04(?:a_p0[7-9]|b_p01)$/,'lounge','宴会厅 · 休息区','formal','neutral'],[/^ch04c_p0[1-3]$/,'dance','宴会厅 · 舞池','formal','strain'],[/^ch04c_p04$/,'car','车内 · 夜','formal','strain'],[/^ch04c_p0[5-6]$/,'hotel','酒店门前 · 夜','formal','strain'],
 [/^ch05a_p0[1-4]$/,'hotel','酒店门前 · 夜','none','neutral'],[/^ch05a_p05$/,'gate','Mo Art Studio · 门外','none','neutral'],[/^ch05b_p0[1-4]$/,'guest','Mo Art Studio · 客卧','crisis','low'],[/^ch05b_p0[5-6]$/,'shore','维罗诺海岸 · 回忆','crisis','strain'],[/^ch05b_p07$/,'guest','Mo Art Studio · 客卧','crisis','low'],
 [/^ch06/,'guest','Mo Art Studio · 客卧','crisis','shock'],[/^ch07a_p0[1-9]$/,'guest','Mo Art Studio · 客卧','crisis','low'],[/^ch07a_p10$/,'bedroom-day','Mo Art Studio · 清晨','home','smile'],
 [/^ch08a_p0[1-7]$/,'bedroom-day','Mo Art Studio · 卧室','home','smile'],[/^ch08a_p0[8-9]$/,'bedroom-day','Mo Art Studio · 卧室','home','tease'],[/^ch08a_p10$/,'bedroom-day','Mo Art Studio · 卧室','home','smile'],[/^ch08a_p1[1-2]$/,'living-night','Mo Art Studio · 客厅','home','firm'],
 [/^ch09a_p0[1-8]$/,'shore','维罗诺海岸 · 旧案','none','neutral'],[/^ch09/,'living-night','Mo Art Studio · 客厅','home','firm'],
 [/^ch10a_p0[1-6]$/,'dream','梦境 · 鳞片森林','none','neutral'],[/^ch10/,'funeral','陈宅 · 葬礼厅','mourning','firm'],
 [/^ch11a_p0[1-3]$/,'funeral','陈宅 · 幻境','mourning','firm'],[/^ch11a_p0[4-6]$/,'funeral-exit','陈宅外 · 烟尘','mourning','shock'],[/^ch11b_p01$/,'funeral-exit','陈宅外 · 烟尘','mourning','shock'],[/^ch11b_p0[2-5]$/,'bedroom-night','Mo Art Studio · 主卧','home','firm'],
 [/^ch12/,'bedroom-night','Mo Art Studio · 主卧','home','low'],[/^ch13/,'bedroom-day','Mo Art Studio · 清晨','home','smile'],
 [/^ifa_p0[1-5]$/,'studio-day','Mo Art Studio · 记忆画室','home','grief'],[/^ifa_p0[6-7]$/,'medical','全隔离病房','home','grief'],[/^ifa_p0[8-9]$/,'gallery','Mo Art Studio · 画像画室','home','grief'],[/^ifa_p10$/,'snow','白沙湾 · 风雪','winter','grief'],[/^ifa_p11$/,'bedroom-night','临空市 · 卧室','none','neutral'],[/^ifa_p1[2-5]$/,'snow','临空市 · 初雪','winter','smile'],[/^ifa_p1[6-7]$/,'living-night','临空市 · 暂住处','winter','smile']
];
const SCENE_ASSETS={
 banquet:'assets/bg/BG_BANQUET_HALL_N.webp',vip:'assets/bg/BG_BANQUET_VIP_N.webp',car:'assets/bg/BG_CAR_INTERIOR_N.webp',guest:'assets/bg/BG_STUDIO_GUEST_N.webp','studio-day':'assets/bg/BG_STUDIO_ART_D.webp','living-day':'assets/bg/BG_STUDIO_LIVING_D.webp','living-night':'assets/bg/BG_STUDIO_LIVING_N.webp','dining-night':'assets/bg/BG_STUDIO_DINING_N.webp',dance:'assets/bg/BG_BANQUET_DANCE_N.webp',lounge:'assets/bg/BG_BANQUET_LOUNGE_N.webp',hotel:'assets/bg/BG_HOTEL_EXT_N.webp',gate:'assets/bg/BG_STUDIO_GATE_N.webp',shore:'assets/bg/BG_SHORE_DUSK.webp','bedroom-night':'assets/bg/BG_STUDIO_BEDROOM_N.webp','bedroom-day':'assets/bg/BG_STUDIO_BEDROOM_D.webp',dream:'assets/bg/BG_DREAM_FOREST.webp',funeral:'assets/bg/BG_FUNERAL_HALL_D.webp','funeral-exit':'assets/bg/BG_FUNERAL_EXIT_D.webp',medical:'assets/bg/BG_MEDICAL_ISOLATION.webp',gallery:'assets/bg/BG_IF_ART_GALLERY.webp',snow:'assets/bg/BG_IF_SNOW_STREET_N_v2.webp'
};
const ACTOR_ASSETS={formal:null,home:null,crisis:null,mourning:null,winter:null};
const V16_ASSETS={
 scent:['assets/scent11/SCENT11_01_SEA.webp','assets/scent11/SCENT11_02_LILY.webp','assets/scent11/SCENT11_03_EMBER.webp'],
 memory:['assets/memory12/MEMORY12_03_INVALID_MARK_v3.webp'],
 winter:['assets/ifgallery/IFGALLERY_01_FIRST_LIGHT.webp','assets/ifgallery/IFGALLERY_02_AFTERNOON.webp','assets/ifgallery/IFGALLERY_03_BEFORE_SNOW.webp']
};
const loadedAssets={};
const assetPromises={};
function warmAsset(path,priority){if(!path)return Promise.resolve(false);if(assetPromises[path])return assetPromises[path];assetPromises[path]=new Promise(resolve=>{const img=new Image();img.decoding='async';if('fetchPriority' in img)img.fetchPriority=priority||'low';img.onload=()=>{loadedAssets[path]=true;const n=N[S.cur],v=n&&n.type==='page'?visualFor(n):null,el=stage&&stage.querySelector('.gal-scene');if(v&&el&&SCENE_ASSETS[v.scene]===path){el.setAttribute('style',sceneStyle(v.scene));el.classList.add('has-asset')}resolve(true)};img.onerror=()=>{delete assetPromises[path];loadedAssets[path]=false;resolve(false)};img.src=path});return assetPromises[path];}
const CORE_ASSETS=['assets/cover-invalid-mark-v122-preview.jpg',SCENE_ASSETS.banquet,SCENE_ASSETS.vip,SCENE_ASSETS.car,SCENE_ASSETS.guest,SCENE_ASSETS['living-day'],SCENE_ASSETS['studio-day'],SCENE_ASSETS['dining-night']];
const DEFERRED_ASSETS=Array.from(new Set(Object.values(SCENE_ASSETS).concat(ENDING_CATALOG.map(item=>item.image),V16_ASSETS.scent,V16_ASSETS.memory,V16_ASSETS.winter)));
let backgroundWarmupStarted=false;
function warmAssetsInOrder(paths,delay){let i=0;function next(){if(i>=paths.length)return;warmAsset(paths[i++],'low').then(()=>setTimeout(next,delay||90));}next();}
function startBackgroundWarmup(){if(backgroundWarmupStarted)return;backgroundWarmupStarted=true;warmAsset(CORE_ASSETS[0],'high');const ordered=Array.from(new Set(CORE_ASSETS.slice(1).concat(DEFERRED_ASSETS)));const begin=()=>warmAssetsInOrder(ordered,110);if('requestIdleCallback' in window)requestIdleCallback(begin,{timeout:1800});else setTimeout(begin,800);}
function warmNextScene(n){if(!n)return;let cursor=n,guard=0;while(cursor&&guard++<10){const nextId=cursor.next||cursor.on_correct;cursor=nextId&&N[nextId];if(cursor&&cursor.type==='page'){const asset=SCENE_ASSETS[visualFor(cursor).scene];if(asset)warmAsset(asset,'high');break;}}}
function sceneFallback(scene,tint){const map={banquet:'radial-gradient(ellipse at 50% -8%,rgba(255,229,180,.5),transparent 18%),linear-gradient(155deg,#3f1624,#171019 56%,#08090d)',vip:'radial-gradient(ellipse at 72% 30%,rgba(225,181,118,.26),transparent 22%),linear-gradient(140deg,#111d28,#2b1c21 55%,#09090e)',car:'linear-gradient(160deg,#141b27,#090b11 66%,#06070a)',guest:'linear-gradient(155deg,#16202a,#24191f 58%,#08090d)','studio-day':'linear-gradient(150deg,#54727a,#2c3e48 53%,#10141b)','living-day':'linear-gradient(150deg,#54727a,#2c3e48 53%,#10141b)','dining-night':'linear-gradient(150deg,#31231e,#151820 62%,#08090d)','living-night':'linear-gradient(150deg,#31231e,#151820 62%,#08090d)',dance:'linear-gradient(145deg,#4a2030,#20131d 57%,#09090e)',lounge:'linear-gradient(145deg,#4a2030,#20131d 57%,#09090e)',hotel:'linear-gradient(155deg,#172630,#11141b 58%,#07080c)',gate:'linear-gradient(155deg,#172630,#11141b 58%,#07080c)',shore:'linear-gradient(178deg,#6f5970 0 35%,#283f4c 36% 61%,#101820)',dream:'linear-gradient(#172128,#06080c)',funeral:'linear-gradient(155deg,#303136,#17181c 56%,#08090c)','funeral-exit':'linear-gradient(155deg,#303136,#17181c 56%,#08090c)',medical:'linear-gradient(155deg,#72818a,#313d46 64%,#11161b)',gallery:'linear-gradient(155deg,#1e2731,#16131b 64%,#08090d)',snow:'linear-gradient(160deg,#53626f,#202c38 60%,#0b1017)'};return map[scene]||`radial-gradient(circle at 50% 12%,${tint||'#24232d'},#06070a 76%)`;}
function sceneStyle(scene,tint){const fallback=sceneFallback(scene,tint);return `--scene-fallback:${fallback};background:${fallback};`;}
function setSceneImage(sceneEl,path){const img=sceneEl&&sceneEl.querySelector('.gal-scene-image');if(!img)return;const expected=path||'';if(img.dataset.asset===expected&&img.getAttribute('src')){if(img.complete&&img.naturalWidth>0)img.classList.add('loaded');return;}img.dataset.asset=expected;img.dataset.retries='0';img.classList.remove('loaded');if(!expected){img.removeAttribute('src');return;}img.onload=()=>{if(img.dataset.asset===expected){img.classList.add('loaded');img.dataset.retries='0';}};img.onerror=()=>{if(img.dataset.asset!==expected)return;img.classList.remove('loaded');const retries=Number(img.dataset.retries||0);if(retries<2){img.dataset.retries=String(retries+1);setTimeout(()=>{if(img.dataset.asset===expected&&!img.classList.contains('loaded'))img.src=expected;},900*(retries+1));}};img.src=expected;if(img.complete&&img.naturalWidth>0)img.classList.add('loaded');}
function visualFor(n){if(VISUAL_OVERRIDES[n.id])return Object.assign({actor:'neutral',actorId:'formal'},VISUAL_OVERRIDES[n.id]);for(const row of SCENE_RANGES)if(row[0].test(n.id))return{scene:row[1],location:row[2],actorId:row[3],actor:row[4]};return{scene:'',location:labelChapter(n),actorId:'none',actor:'neutral'};}
function inferredBeat(text){const t=String(text||'').trim();if(!t)return{kind:'narration',speaker:'旁白'};if(/^[【].+[】]$/.test(t))return{kind:'artifact',speaker:'记录'};if(/你(?:想|心想|暗想|腹诽|想着|疑惑|意识到)/.test(t)&&!/[“”]/.test(t))return{kind:'thought',speaker:'心声'};if(!/^“/.test(t))return{kind:'narration',speaker:'旁白'};if(/^“(?:啪|砰|铛|叮|滴滴|嗡|哒)/.test(t))return{kind:'ambient',speaker:'声响'};if(/(?:祁煜|祁先生|Alpha|他)(?:问|说|道|回应|开口|低语|轻声|哑声|呢喃|反问|重复|笑)|(?:祁煜|祁先生|Alpha)的(?:声音|话音|嗓音)|他说/.test(t))return{kind:'dialogue',speaker:'祁煜'};if(/(?:你|你说|你问|你答|你开口|你回应|你反问|你嘟囔|你低声|你轻声)/.test(t))return{kind:'dialogue',speaker:'你'};if(/唐知理|唐先生/.test(t))return{kind:'dialogue',speaker:'唐知理'};if(/陈兴业|陈总/.test(t))return{kind:'dialogue',speaker:'陈兴业'};if(/医生/.test(t))return{kind:'dialogue',speaker:'医生'};return{kind:'narration',speaker:'旁白'};}
const ADDED_BEAT_OVERRIDES={
 'ch03a_p02|“叮。”':{kind:'ambient',speaker:'声响'},
 'ch03a_p02|“吃饭啦。”':{kind:'dialogue',speaker:'祁煜'},
 'ch04a_p03|“果然应该相信……”不知何时出现的Alpha将发呆的你从沙发上拉起，手上拿着刚从礼盒中拆封的长裙。祁煜将长裙对齐你的肩颈，比划着预测上身后的效果，“我的审美。”':{kind:'dialogue',speaker:'祁煜'},
 'ch04a_p03|“祖宗，你怎么又到处溜达……上次那幅画你还没改到满意吗？”被祁煜打断的唐知理站在一旁，唉声叹气。':{kind:'dialogue',speaker:'唐知理'},
 'ch04a_p03|“啧。那幅在我画室里，别的你别碰。”祁煜随口打发道。':{kind:'dialogue',speaker:'祁煜'},
 'ch04a_p03|“好嘞。”唐知理头也不回，便往画室里走去。':{kind:'dialogue',speaker:'唐知理'},
 'ch04a_p03|“终于笑了。”祁煜捏了捏你的侧颊，夸张地抱怨，“从刚刚起就一直愁眉苦脸，姓唐的欺负你啦？”':{kind:'dialogue',speaker:'祁煜'},
 'ch04a_p03|“别想啦。”Alpha揉了揉你的脸，指尖怜惜地抚过你的眼下与面颊，“快去把裙子换上。”':{kind:'dialogue',speaker:'祁煜'},
 'ch04b_p01|“我刚才分明闻到了你身上的信息素……”':{kind:'dialogue',speaker:'陌生男子'},
 'ch07a_p10|“……”你一下子被这四个字击中了。潮湿的热气去而复返，将你的面颊蒸腾出朦胧的红晕。':{kind:'narration',speaker:'旁白'},
 'ch08a_p06|“现在我欠了好多好多句喜欢要说给你听，你可不能嫌我吵。”':{kind:'dialogue',speaker:'祁煜'},
 'ch08a_p10|“……”祁煜终于听出了你的调侃，“好啊，你故意笑话我是不是？”':{kind:'dialogue',speaker:'祁煜'},
 'ch08a_p10|“我可没有。”方才没忍住的笑意全被你憋了回去。可才过一会儿，那些坏心眼又冒出来了。':{kind:'dialogue',speaker:'你'},
 'ch08a_p10|你兴致勃勃地问：“那你规定24小时跟在雇主身边，是为什么？”':{kind:'dialogue',speaker:'你'},
 'ch09c_p01|“宝宝……宝贝。”祁煜捧着你的面颊便不放了。他一遍遍吻去你眼角的湿润，反复说着温软的爱语，低声哄你：“不哭了好不好？这些天你脱水太严重了……宝宝、我的宝宝。”':{kind:'dialogue',speaker:'祁煜'},
 'ch09c_p01|“疼吗？”你的手轻轻抚上祁煜的左胸。隔着一层名贵的衬衫布料，你感受到Alpha平缓的心跳逐渐加速，擂鼓般震耳欲聋。':{kind:'dialogue',speaker:'你'},
 'ch09c_p01|“我会心疼。”剔透的水珠无声从你眼角滑落。你像是自己都觉得这情绪太过矫情，一句多余的解释也不肯再说，只是一个劲儿地捂着自己的左胸，唇瓣被齿尖咬出一片弥漫开的青白。':{kind:'dialogue',speaker:'你'}
};
function beatMeta(n,i,text){
 const source=DISPLAY_SOURCE[n.id+'|'+text]||text;
 const added=ADDED_BEAT_OVERRIDES[n.id+'|'+source];if(added)return added;
 const originals=window.INVALID_MARK_ORIGINAL_TEXT&&window.INVALID_MARK_ORIGINAL_TEXT[n.id];
 const originalIndex=originals?originals.indexOf(source):-1;
 const preserved=originalIndex>=0&&BEAT_OVERRIDES[n.id]&&BEAT_OVERRIDES[n.id][originalIndex];
 return preserved||inferredBeat(source);
}
function autoDelay(text){return Math.max(2600,Math.min(7200,1500+String(text||'').length*68));}
function scheduleAutoAdvance(n,text){
 clearAutoTimer();if(!S.autoPlay||S.mode!=='gal'||!n||n.type!=='page')return;
 const parts=textParts(n),atLast=S.beat>=parts.length-1;
 if(atLast&&(n.ending||!n.next||N[n.next]&&N[n.next].type!=='page'))return;
 autoTimer=setTimeout(()=>{autoTimer=null;if(!S.autoPlay||S.cur!==n.id||S.mode!=='gal')return;advancePage(n);},autoDelay(text));
}
function toggleAutoPlay(){S.autoPlay=!S.autoPlay;save();render();inform(S.autoPlay?'自动播放已开启':'自动播放已关闭');}
function render(){clearAutoTimer();resetTyping();closeOv();let n=N[S.cur];if(!n){inform('节点缺失');return;}document.body.dataset.mode=S.mode;document.body.dataset.nodeType=n.type;$('#btnMode').textContent=S.mode==='read'?'视觉':'沉浸';const backButton=$('#btnBack'),backAvailable=canBack();backButton.disabled=!backAvailable;backButton.style.opacity=backAvailable?1:.35;backButton.title=backAvailable?'返回上一节点':'已经是故事起点';backButton.setAttribute('aria-label',backButton.title);showBar(n);if(!(n.type==='page'&&S.mode==='gal'))stage.scrollTop=0;
 warmNextScene(n);
 if(n.type==='chapter')renderChapter(n);
 else if(n.type==='page')renderPage(n);
 else if(n.type==='choice')renderChoice(n);
 else if(n.type==='document')renderContractChat(n);
 else if(n.type==='rhythm')renderRhythm(n);
 else if(n.type==='keypad')renderGateLock(n);
 else if(n.type==='casefile')renderCasefile(n);
 else if(n.type==='scent')renderScent(n);
 else if(n.type==='memory')renderMemory(n);
 else if(n.type==='gallery')renderGallery(n);
 else if(n.type==='ending')renderEnding(n);
 else{stage.innerHTML='<div class="wrap"><p>不支持的节点：'+esc(n.type)+'</p></div>';foot.onclick=null;}
}
function renderChapter(n){delete document.body.dataset.sliceScene;delete stage.dataset.layout;delete stage.dataset.sceneKey;document.body.style.background='';const raw=n.title||'';const title=raw.split('｜').slice(1).join('｜')||raw;stage.innerHTML='<div class="card"><div class="num">CHAPTER '+esc(n.chapter)+'</div><h1>'+esc(title)+'</h1><div class="rule"></div><p>'+(n.chapter==='01'?'开始故事':'故事仍在继续')+'</p><button class="enter" id="enterChapter">进入本章</button></div>';
 $('#enterChapter').onclick=()=>go(n.next);footHint.innerHTML='进入本章　<b>▸</b>';foot.onclick=()=>go(n.next);}
function advancePage(n){if(typing){finishTyping();return;}const arr=textParts(n);if(S.mode==='gal'&&S.beat<arr.length-1){S.beat++;renderPage(n);save();return;}if(n.ending){showEndingPage(n.chapter==='IF'?'IF_WINTER':'TRUE_LONGEVITY');return;}if(n.next)go(n.next);else showEndingPage(n.chapter==='IF'?'IF_WINTER':'TRUE_LONGEVITY');}
function renderPage(n){const arr=textParts(n), echo=echoFor(n);if(S.mode==='gal'){
 document.body.style.background='';let bi=Math.min(S.beat,arr.length-1),text=arr[bi]||'',visual=visualFor(n),meta=beatMeta(n,bi,text);
 document.body.dataset.sliceScene=visual.scene||'';document.body.dataset.scene=visual.scene||'';
 const sceneAsset=SCENE_ASSETS[visual.scene],actorAsset=ACTOR_ASSETS[visual.actorId];warmAsset(sceneAsset,'high');warmAsset(actorAsset);if(n.chapter==='11')V16_ASSETS.scent.forEach(path=>warmAsset(path,'low'));else if(n.chapter==='12')V16_ASSETS.memory.forEach(path=>warmAsset(path,'low'));else if(n.chapter==='IF')V16_ASSETS.winter.forEach(path=>warmAsset(path,'low'));
 const tints={'01':'#4a1a26','02':'#122238','03':'#3a2416','04':'#3a1a40','05':'#0e2230','06':'#22222a','07':'#3a2718','08':'#0d2e33','09':'#201a34','10':'#2e2128','11':'#232323','12':'#3c1626','13':'#12301f','IF':'#1a2634'};
 const tint=tints[n.chapter]||'#24232d',sceneKey=visual.scene||n.chapter;if(stage.dataset.layout!=='gal'){stage.innerHTML='<div class="gal"><div class="gal-scene scene-layer"><img class="gal-scene-image" alt="" aria-hidden="true" decoding="async"></div><div class="gal-glow"></div><div class="gal-wm"></div><div class="gal-shadow"></div><div class="gal-location"></div><div class="gal-actor" aria-hidden="true"><i class="head"></i><i class="body"></i></div><div class="gal-sense"></div><div class="gal-vig"></div><div class="gal-copy"><div class="gal-name"></div><div class="gal-box"><p class="tp" id="galLine"></p></div><button type="button" class="gal-auto" id="galAuto" aria-label="切换自动播放">自动</button></div><div class="gal-beat"></div></div>';stage.dataset.layout='gal';}
 const gal=stage.querySelector('.gal'),sceneEl=stage.querySelector('.gal-scene'),actorEl=stage.querySelector('.gal-actor'),line=stage.querySelector('#galLine');gal.style.setProperty('--tint',tint);if(stage.dataset.sceneKey!==sceneKey){const pendingScene=sceneKey;sceneEl.dataset.pendingScene=pendingScene;sceneEl.classList.add('out');requestAnimationFrame(()=>{if(sceneEl.dataset.pendingScene!==pendingScene)return;sceneEl.setAttribute('style',sceneStyle(visual.scene,tint));sceneEl.className='gal-scene scene-layer';sceneEl.dataset.pendingScene=pendingScene;setSceneImage(sceneEl,sceneAsset);requestAnimationFrame(()=>{if(sceneEl.dataset.pendingScene===pendingScene)sceneEl.classList.remove('out');});});stage.dataset.sceneKey=sceneKey;}else{setSceneImage(sceneEl,sceneAsset);}
 stage.querySelector('.gal-wm').textContent=n.chapter;stage.querySelector('.gal-location').textContent=visual.location;stage.querySelector('.gal-name').className='gal-name '+meta.kind;stage.querySelector('.gal-name').textContent=meta.speaker;stage.querySelector('.gal-box').className='gal-box '+meta.kind;stage.querySelector('.gal-beat').textContent=(S.beat+1)+' / '+arr.length;stage.querySelector('.gal-sense').className='gal-sense '+(visual.sense?'on':'');const actorReady=!!(actorAsset&&loadedAssets[actorAsset]);actorEl.className='gal-actor actor-'+visual.actorId+' '+visual.actor+(actorReady?' has-asset':' actor-none');if(actorReady)actorEl.style.setProperty('--actor-image','url("'+actorAsset+'")');else actorEl.style.removeProperty('--actor-image');line.textContent='';
 startTyping($('#galLine'),text);
 const autoButton=$('#galAuto');if(autoButton){autoButton.classList.toggle('on',!!S.autoPlay);autoButton.textContent=S.autoPlay?'自动中':'自动';autoButton.title=S.autoPlay?'关闭自动播放':'开启自动播放';autoButton.onclick=e=>{e.stopPropagation();toggleAutoPlay();};}
 scheduleAutoAdvance(n,text);
 }else{delete document.body.dataset.sliceScene;delete document.body.dataset.scene;delete stage.dataset.layout;delete stage.dataset.sceneKey;document.body.style.background='';stage.innerHTML='<div class="wrap"><div class="reading-counter">'+esc(n.chapter)+' · '+(n.src?n.src.join('–'):'剧情')+'</div><div class="paras">'+arr.map((v,i)=>'<p class="tp'+(echo&&i===arr.length-1?' extra-echo':'')+'">'+esc(v)+'</p>').join('')+'</div></div>';}
 footHint.innerHTML=n.ending?'结局 · '+esc(n.ending)+'　<b>▸</b>':'轻点继续　<b>▸</b>';foot.onclick=()=>advancePage(n);}
function choiceBody(n){let h='<div class="choice"><div class="game-eyebrow">'+esc(n.scene||'抉择时刻')+'</div><p class="prompt"><span class="q">◇</span>'+esc(n.prompt)+'</p>';
 if(n.observations){h+='<div class="invest-grid">'+n.observations.map((o,i)=>'<button class="invest-item" data-ob="'+i+'">观察 · '+esc(o.title)+'</button>').join('')+'</div><div class="info-panel" id="obInfo" style="display:none"></div>';}
 h+='<ol>'+n.options.map((o,i)=>'<li><button class="opt" data-choice="'+i+'"><span class="idx">'+['①','②','③','④','⑤'][i]+'</span>'+esc(o.label)+'</button></li>').join('')+'</ol></div>';return h;}
function renderChoice(n){delete stage.dataset.layout;delete stage.dataset.sceneKey;document.body.style.background='';const scene=n.id==='E1'?'banquet':n.id==='T2'?'dining-night':n.id==='T3'?'lounge':n.id==='E3'?'living-night':n.id==='T7'?'funeral-exit':n.id==='E4'?'bedroom-night':'';document.body.dataset.sliceScene=scene;document.body.dataset.scene=scene;stage.innerHTML=(n.id==='E1'?'<div class="slice-choice">':'<div class="game-shell choice-shell">')+choiceBody(n)+'</div>';footHint.innerHTML='做出选择　<b>▸</b>';foot.onclick=null;
 if(n.id==='E1'&&n.observations){for(const i of S.flags['observed_'+n.id]||[]){const b=stage.querySelector('[data-ob="'+i+'"]');if(b)b.classList.add('seen');}}
 for(const btn of stage.querySelectorAll('[data-ob]'))btn.onclick=()=>{const i=Number(btn.dataset.ob),o=n.observations[i];btn.classList.add('seen');let seen=S.flags['observed_'+n.id]||[];if(!seen.includes(i))seen.push(i);S.flags['observed_'+n.id]=seen;$('#obInfo').style.display='block';$('#obInfo').textContent=o.body;save();};
 for(const btn of stage.querySelectorAll('[data-choice]'))btn.onclick=()=>{const o=n.options[+btn.dataset.choice];Object.assign(S.flags,o.effects||{});save();if(o.extra&&o.extra.length)showExtra(o.extra,o.next);else go(o.next);};}
function showExtra(paras,nextId,kind){if(!nextId||!N[nextId]){inform('后续剧情节点缺失');return;}S.flags.pending_next=nextId;save();ovIn.className='in'+(kind==='signed'?' center':'');ovIn.innerHTML=(kind==='signed'?'<div class="sign-transition"><div class="seal">✓</div>':'')+paras.map(t=>'<p>'+esc(t)+'</p>').join('')+'<div class="btns"><button class="pri" data-continue-node="'+esc(nextId)+'">继续故事</button></div>'+(kind==='signed'?'</div>':'');ov.classList.add('on');ov.scrollTop=0;}
function showSigned(paras,nextId){showExtra(paras,nextId,'signed');}
function renderContractChat(n){
 let view='chat',seen=new Set(S.flags.contract_v12_seen||[]),asked=!!S.flags.contract_v12_asked,signed=!!S.flags.contract_v12_signed;
 const nextId=n.next;
 function leave(){
  if(!nextId||!N[nextId]){inform('第二章后续剧情节点缺失');return;}
  S.cur=nextId;S.beat=0;S.visited[nextId]=(S.visited[nextId]||0)+1;if(S.stack[S.stack.length-1]!==n.id)S.stack.push(n.id);save();render();
 }
 function shell(content,back){return '<div class="contract-v12-stage"><div class="contract-v12-layout"><div class="contract-v12-context"><span>MO ART STUDIO · 23:48</span><h2>一份新的委托</h2><p>唐知理发来了转账与补充协议。那些看似细小的限制，正在悄悄改变这份工作的边界。</p></div><section class="contract-v12-device"><header class="contract-v12-head">'+(back?'<button type="button" class="contract-v12-back" id="contractBack">← 返回</button>':'<div class="contract-v12-avatar">唐</div>')+'<div class="contract-v12-contact"><strong>'+(back?'委托协议补充条款':'唐知理')+'</strong><small>'+(back?'MO-ART / 待签署':'在线 · 工作联系人')+'</small></div></header>'+content+'</section></div></div>';}
 function renderChat(){
  view='chat';const extra=asked?'<div class="contract-v12-row me"><div class="contract-v12-bubble">为什么会有这些限制？</div></div><div class="contract-v12-row"><div class="contract-v12-bubble">有些话不该由我来说。您先看完协议，就当是祁先生的意思吧。</div></div>':'';
  const signedRows=signed?'<div class="contract-v12-row me"><div class="contract-v12-bubble">我已经签好了。</div></div><div class="contract-v12-row"><div class="contract-v12-bubble">文件已收到。之后的安排我会再和您确认，今晚请先好好休息。</div></div>':'';
  stage.innerHTML=shell('<div class="contract-v12-chat"><div class="contract-v12-time">今天 23:48</div><div class="contract-v12-transfer"><small>委托定金已到账</small><strong>¥ 500,000.00</strong></div><div class="contract-v12-row"><div class="contract-v12-bubble">小姐您好，之前签订的委托协议有一些条款变动。请您过目；如果同意接受雇佣，签字后回传给我。</div></div><button type="button" class="contract-v12-file" id="contractOpen"><span class="icon">DOC</span><span><strong>'+esc(n.title)+'</strong><small>'+(signed?'已签署 · 点击再次查看':'电子文件 · 点击查看')+'</small></span><b>›</b></button>'+extra+signedRows+'<div class="contract-v12-actions">'+(!asked&&!signed?'<button type="button" class="contract-v12-secondary" id="contractAsk">询问条款缘由</button>':'<span></span>')+(signed?'<button type="button" class="contract-v12-primary" id="contractContinue">继续故事 →</button>':'<button type="button" class="contract-v12-primary" id="contractOpenBottom">查看契约 →</button>')+'</div></div>',false);
  const open=()=>{view='document';S.flags.contract_v12_opened=true;save();renderDocumentView();};$('#contractOpen').onclick=open;const openBottom=$('#contractOpenBottom');if(openBottom)openBottom.onclick=open;const ask=$('#contractAsk');if(ask)ask.onclick=()=>{asked=true;S.flags.contract_v12_asked=true;save();renderChat();};const cont=$('#contractContinue');if(cont)cont.onclick=leave;
  footHint.innerHTML=signed?'继续第二章剧情　<b>▸</b>':'打开契约并查看条款';foot.onclick=signed?leave:null;
 }
 function renderDocumentView(){
  view='document';stage.innerHTML=shell('<div class="contract-v12-document"><div class="contract-v12-docmeta"><span>MO ART STUDIO · SUPPLEMENT</span><h3>'+esc(n.title)+'</h3><small>点击条款可查看你的即时想法</small></div>'+n.clauses.map((c,i)=>'<button type="button" class="contract-v12-clause '+(seen.has(i)?'active':'')+'" data-contract-clause="'+i+'"><small>第 '+(i+1)+' 项 · '+esc(c.title)+'</small><span>'+esc(c.body)+'</span>'+(seen.has(i)?'<em>「'+esc(c.reaction)+'」</em>':'')+'</button>').join('')+'<div class="contract-v12-sign"><button type="button" class="contract-v12-secondary" id="contractReturn">返回聊天</button>'+(signed?'<button type="button" class="contract-v12-primary" id="contractSignedReturn">已签署 · 返回聊天</button>':'<button type="button" class="contract-v12-primary" id="contractSign">签署并回传 →</button>')+'</div></div>',true);
  stage.querySelectorAll('[data-contract-clause]').forEach(btn=>btn.onclick=()=>{seen.add(Number(btn.dataset.contractClause));S.flags.contract_v12_seen=Array.from(seen);save();renderDocumentView();});const back=()=>renderChat();$('#contractBack').onclick=back;$('#contractReturn').onclick=back;const signedReturn=$('#contractSignedReturn');if(signedReturn)signedReturn.onclick=back;const sign=$('#contractSign');if(sign)sign.onclick=()=>{signed=true;S.flags.contract_v12_signed=true;S.flags.contract_v12_seen=Array.from(seen);S.flags.contract_v12_read=asked?'问过唐知理':seen.size>=4?'细读条款':'快速签署';save();renderChat();};
  footHint.textContent=signed?'协议已经签署':'查看条款并签署';foot.onclick=null;
 }
 delete stage.dataset.layout;delete stage.dataset.sceneKey;document.body.dataset.sliceScene='contract';document.body.dataset.scene='contract';document.body.style.background='';renderChat();
}
function renderRhythm(n){
 let step=0,moved=false;
 const lines=['祁煜向你伸出手：“先别看脚。看着我。”','“左脚向前。对，慢一点。”','“现在把重心交给我。”','他带着你转过半圈，笑意落进金色灯影里：“很好，这次没踩到我。”'];
 const nextId=n.next;
 function leave(done){
  if(!nextId||!N[nextId]){inform('第四章后续剧情节点缺失');return;}
  S.flags.dance_completed=!!done;S.flags.dance_step=step;S.cur=nextId;S.beat=0;S.visited[nextId]=(S.visited[nextId]||0)+1;if(S.stack[S.stack.length-1]!==n.id)S.stack.push(n.id);save();render();
 }
 function redraw(){
  stage.innerHTML='<div class="waltz-stage"><section class="waltz-card" aria-label="华尔兹练习"><header class="waltz-head"><div class="waltz-kicker">CHAPTER 04 · WALTZ</div><h2>跟紧我的脚步</h2><div class="waltz-progress">'+(step<3?'练习 '+step+' / 3':'练习完成')+'</div></header><div class="waltz-floor"><div class="waltz-pair '+(moved?'moved':'')+'" role="img" aria-label="背对镜头共舞的男女主角"></div></div><p class="waltz-line">'+esc(lines[step])+'</p><div class="waltz-steps">'+[['向前','左脚'],['侧步','跟随'],['并步','旋转']].map((v,i)=>'<button type="button" class="waltz-step '+(i<step?'done':i===step&&step<3?'active':'')+'" data-waltz-step="'+i+'" '+(i!==step||step>=3?'disabled':'')+'><span>0'+(i+1)+'</span>'+v[0]+' · '+v[1]+'</button>').join('')+'</div><div class="waltz-status">'+(step<3?'依次完成三个舞步。选错不会扣除任何进度。':'舞步已经完成，可以继续参加宴会。')+'</div><div class="waltz-actions"><button type="button" class="secondary" id="waltzSkip">直接进入后续剧情</button><button type="button" class="primary" id="waltzContinue" '+(step<3?'disabled':'')+'>继续第四章剧情 →</button></div></section></div>';
 const current=stage.querySelector('[data-waltz-step="'+step+'"]');if(current)current.onclick=()=>{step++;moved=true;redraw();};
 const skip=stage.querySelector('#waltzSkip'),cont=stage.querySelector('#waltzContinue');skip.onclick=()=>leave(false);if(step>=3)cont.onclick=()=>leave(true);
  footHint.innerHTML=step>=3?'继续第四章剧情　<b>▸</b>':'直接进入后续剧情　<b>▸</b>';foot.onclick=()=>leave(step>=3);
 }
 delete stage.dataset.layout;delete stage.dataset.sceneKey;document.body.dataset.sliceScene='dance';document.body.dataset.scene='dance';document.body.style.background='';redraw();
}
function renderGateLock(n){
 let digits=[0,0,0,0],clue=-1,tries=0;
 const nextId=n.on_correct;
 function leave(method){
  if(!nextId||!N[nextId]){inform('第五章后续剧情节点缺失');return;}
  S.flags.gate_solved=method;S.flags.gate_v11_opened=true;S.flags.gate_v11_code=digits.join('');
  S.cur=nextId;S.beat=0;S.visited[nextId]=(S.visited[nextId]||0)+1;if(S.stack[S.stack.length-1]!==n.id)S.stack.push(n.id);save();render();
 }
 function redraw(message,error){
  const code=digits.join('');
  stage.innerHTML='<div class="gate-v11-stage"><section class="gate-v11-shell"><div class="gate-v11-photo"><div class="gate-v11-photo-copy"><span>MO ART STUDIO · ACCESS</span><strong>门禁锁芯</strong><small>四位数字。一个对他而言特殊的日期。</small></div></div><div class="gate-v11-panel"><div class="gate-v11-kicker">CHAPTER 05 · ACCESS CONTROL</div><h2>转动密码轮</h2><p class="gate-v11-desc">分别转动四枚数字轮。确认密码后，锁芯会直接开启并进入屋内。</p><div class="gate-v11-wheels">'+digits.map((d,i)=>'<div class="gate-v11-wheel"><button type="button" data-wheel-up="'+i+'" aria-label="增加第 '+(i+1)+' 位数字">⌃</button><div class="gate-v11-digit">'+d+'</div><button type="button" data-wheel-down="'+i+'" aria-label="减少第 '+(i+1)+' 位数字">⌄</button></div>').join('')+'</div><div class="gate-v11-clues">'+n.clues.map((c,i)=>'<button type="button" class="gate-v11-clue '+(clue===i?'active':'')+'" data-gate-clue="'+i+'">线索 0'+(i+1)+'</button>').join('')+'</div><div class="gate-v11-clue-text">'+(clue>=0?esc(n.clues[clue]):'选择一份线索。公开生日并不一定是答案。')+'</div><div class="gate-v11-feedback '+(error?'error':'')+'">'+esc(message||('当前密码 · '+code))+'</div><div class="gate-v11-actions"><button type="button" class="gate-v11-remote" id="gateRemote">联系唐知理远程开门</button><button type="button" class="gate-v11-submit" id="gateSubmit">确认密码并开门 →</button></div></div></section></div>';
  stage.querySelectorAll('[data-wheel-up]').forEach(btn=>btn.onclick=e=>{e.stopPropagation();const i=Number(btn.dataset.wheelUp);digits[i]=(digits[i]+1)%10;redraw();});
  stage.querySelectorAll('[data-wheel-down]').forEach(btn=>btn.onclick=e=>{e.stopPropagation();const i=Number(btn.dataset.wheelDown);digits[i]=(digits[i]+9)%10;redraw();});
  stage.querySelectorAll('[data-gate-clue]').forEach(btn=>btn.onclick=e=>{e.stopPropagation();clue=Number(btn.dataset.gateClue);redraw();});
  stage.querySelector('#gateRemote').onclick=e=>{e.stopPropagation();leave('远程解锁');};
  stage.querySelector('#gateSubmit').onclick=e=>{e.stopPropagation();if(digits.join('')===String(n.answer)){leave('独立破解');return;}tries++;S.tries=(S.tries||0)+1;const codeNow=digits.join(''),feedback=n.wrong_feedback[codeNow]||n.wrong_feedback.other||['密码不正确。'];redraw(feedback.join(' ')+(tries>=2?' 可以查看线索，或联系唐知理。':''),true);save();};
  footHint.textContent='转动密码轮，确认后直接开门';foot.onclick=null;
 }
 delete stage.dataset.layout;delete stage.dataset.sceneKey;document.body.dataset.sliceScene='gate';document.body.dataset.scene='gate';document.body.style.background='';redraw();
}
function renderCasefile(n){
 const images=['assets/case09/CASE09_01_COAST.webp','assets/case09/CASE09_02_OPERA.webp','assets/case09/CASE09_03_PORTRAIT.webp','assets/case09/CASE09_04_WINERY.webp','assets/case09/CASE09_05_BANQUET.webp'];
 const storedActive=S.flags.case_v14_active;
 let seen=new Set(S.flags.case_v14_seen||[]),active=Number.isInteger(storedActive)&&storedActive>=0&&storedActive<n.items.length?storedActive:-1;
 const nextId=n.next;
 function openFile(i){active=i;seen.add(i);S.flags.case_v14_active=i;S.flags.case_v14_seen=Array.from(seen);S.flags.case_count=Math.max(S.flags.case_count||0,seen.size);save();redraw();}
 function leave(method){
  if(!nextId||!N[nextId]){inform('第九章后续剧情节点缺失');return;}
  S.flags.case_v14_completed=seen.size===n.items.length;S.flags.case_v14_method=method;S.flags.case_v14_seen=Array.from(seen);S.cur=nextId;S.beat=0;S.visited[nextId]=(S.visited[nextId]||0)+1;if(S.stack[S.stack.length-1]!==n.id)S.stack.push(n.id);save();render();
 }
 function redraw(){
  const item=active>=0?n.items[active]:null,image=active>=0?images[active]:'assets/case09/BG_CASE09_ARCHIVE_DESK.webp';
  stage.innerHTML='<div class="case-v14-stage"><section class="case-v14-shell"><aside class="case-v14-index"><div class="case-v14-kicker">CHAPTER 09 · ARCHIVE</div><h2>旧案档案室</h2><p class="case-v14-intro">五份记录来自不同时间与地点。无需回答问题；打开档案，只是为了看清它们之间的联系。</p><div class="case-v14-count"><span>档案索引</span><span>已阅 '+seen.size+' / '+n.items.length+'</span></div><div class="case-v14-list">'+n.items.map((it,i)=>'<button type="button" class="case-v14-file '+(seen.has(i)?'seen ':'')+(active===i?'active':'')+'" data-case-v14="'+i+'"><span class="case-v14-thumb" style="background-image:url(&quot;'+images[i]+'&quot;)"></span><span><strong>'+esc(it.title)+'</strong><small>'+esc(it.tag)+'</small></span><b>›</b></button>').join('')+'</div><div class="case-v14-seal">MO ART · RESTRICTED FILE</div></aside><div class="case-v14-view"><div class="case-v14-photo '+(item?'':'intro')+'" style="background-image:url(&quot;'+image+'&quot;)">'+(item?'<div class="case-v14-stamp">EVIDENCE 0'+(active+1)+'</div>':'')+'<div class="case-v14-caption"><span>'+(item?'ARCHIVE 0'+(active+1)+' · '+esc(item.tag):'RESTRICTED ARCHIVE · CASE 09')+'</span><h3>'+(item?esc(item.title):'被藏起来的真相')+'</h3></div></div><div class="case-v14-detail">'+(item?'<div class="lead">线索记录</div><p>'+esc(item.body)+'</p>':'<div class="lead">档案说明</div><p>'+esc(n.prompt)+' 你可以逐份查看，也可以随时完成归档并继续故事。</p>')+'</div><div class="case-v14-actions"><button type="button" class="case-v14-review" id="caseV14Next">'+(active<0?'打开第一份档案':'查看下一份档案')+'</button><button type="button" class="case-v14-continue" id="caseV14Continue">完成归档，继续剧情 →</button></div></div></section></div>';
  stage.querySelectorAll('[data-case-v14]').forEach(btn=>btn.onclick=e=>{e.stopPropagation();openFile(Number(btn.dataset.caseV14));});$('#caseV14Next').onclick=e=>{e.stopPropagation();openFile(active<0?0:(active+1)%n.items.length);};$('#caseV14Continue').onclick=e=>{e.stopPropagation();leave('档案页按钮');};footHint.innerHTML='完成归档，继续剧情　<b>▸</b>';foot.onclick=()=>leave('底部继续');
 }
 delete stage.dataset.layout;delete stage.dataset.sceneKey;document.body.dataset.sliceScene='case-archive';document.body.dataset.scene='case-archive';document.body.style.background='';redraw();
}
function renderScent(n){
 let step=Math.max(0,Math.min(3,Number(S.flags.scent_v17_stage)||0));
 const lines=['烟尘呛进喉咙。可在焦灼的空气里，还有什么正缓慢靠近。','冷冽的潮气漫上来，是一片安静而辽阔的海。','海潮之后，白百合的香气被风托起，迎面而来。','最深处压着一点余烬般的暖意。海、百合与火，终于在这一刻有了同一个名字。'];
 const nextId=n.next;
 function leave(){
  if(!nextId||!N[nextId]){inform('第十一章后续剧情节点缺失');return;}
  S.flags.scent_v15_completed=true;S.flags.scent_v17_stage=0;S.flags.told_scent='闻见';S.cur=nextId;S.beat=0;S.visited[nextId]=(S.visited[nextId]||0)+1;if(S.stack[S.stack.length-1]!==n.id)S.stack.push(n.id);save();render();
 }
 function update(){
  const root=stage.querySelector('.scent-v15-stage');if(!root)return;root.dataset.scentStep=step;
  const line=stage.querySelector('.scent-v15-line');if(line)line.textContent=lines[step];
  const hint=stage.querySelector('.scent-v15-hint');if(hint)hint.textContent=step<3?'轻触气息 · '+(step+1)+' / 3':'气息已经清晰';
  stage.querySelectorAll('.scent-v15-note').forEach((el,i)=>el.classList.toggle('active',i<step));
  const cont=stage.querySelector('#scentV15Continue');if(cont)cont.disabled=step<3;
  footHint.innerHTML=step>=3?'继续第十一章剧情　<b>▸</b>':'轻触画面，辨认气息';foot.onclick=step>=3?leave:null;
 }
 const petals=Array.from({length:14},(_,i)=>'<i class="scent-v16-particle petal" style="left:'+((9+i*19)%88)+'%;top:'+(18+(i*23)%62)+'%;--dur:'+(5.4+(i%5)*.8)+'s;--delay:-'+(i*.63)+'s"></i>').join('');
 const sparks=Array.from({length:22},(_,i)=>'<i class="scent-v16-particle spark" style="left:'+((6+i*29)%91)+'%;top:'+(35+(i*17)%55)+'%;--size:'+(2+i%4)+'px;--dur:'+(3.1+(i%6)*.45)+'s;--delay:-'+(i*.37)+'s;--drift:'+(-24+(i*13)%49)+'px"></i>').join('');
 stage.innerHTML='<div class="scent-v15-stage" data-scent-step="'+step+'"><section class="scent-v15-shell"><div class="scent-v15-visual"><span class="scent-v16-layer sea"></span><span class="scent-v16-layer lily"></span><span class="scent-v16-layer ember"></span><span class="scent-v16-shade"></span><button type="button" class="scent-v15-touch" id="scentV15Touch" aria-label="轻触以辨认祁煜的信息素"><span class="scent-v16-current c1"></span><span class="scent-v16-current c2"></span><span class="scent-v16-current c3"></span>'+petals+sparks+'<span class="scent-v15-core"><span class="scent-v15-symbol">TOUCH<br>TRACE</span></span><span class="scent-v15-hint"></span></button></div><div class="scent-v15-copy"><div class="scent-v15-kicker">CHAPTER 11 · SCENT TRACE</div><h2>闻见他</h2><p class="scent-v15-intro">'+esc(n.prompt)+'</p><div class="scent-v15-notes">'+n.notes.map((item,i)=>'<div class="scent-v15-note '+(i<step?'active':'')+'"><b>0'+(i+1)+'</b><span>'+esc(item.title)+'<small>'+esc(item.body)+'</small></span></div>').join('')+'</div><p class="scent-v15-line">'+esc(lines[step])+'</p><button type="button" class="scent-v15-continue" id="scentV15Continue" '+(step<3?'disabled':'')+'>我闻到了 · 继续故事 →</button></div></section></div>';
 const touch=stage.querySelector('#scentV15Touch');touch.onclick=e=>{const rect=touch.getBoundingClientRect(),burst=document.createElement('i');burst.className='scent-v15-burst tone-'+Math.min(3,step+1);burst.style.left=(e.clientX-rect.left)+'px';burst.style.top=(e.clientY-rect.top)+'px';touch.appendChild(burst);burst.addEventListener('animationend',()=>burst.remove());if(step<3){step++;S.flags.scent_v17_stage=step;save();update();}};
 stage.querySelector('#scentV15Continue').onclick=leave;
 delete stage.dataset.layout;delete stage.dataset.sceneKey;document.body.dataset.sliceScene='funeral-exit';document.body.dataset.scene='funeral-exit';document.body.style.background='';update();
}
function renderMemory(n){
 let i=Math.max(0,Math.min(n.items.length-1,Number(S.flags.memory_v15_index)||0));
 const nextId=n.next;
 function leave(){
  if(!nextId||!N[nextId]){inform('第十二章最终选择节点缺失');return;}
  S.flags.memories_read=true;S.flags.memory_v15_completed=true;S.flags.memory_v15_index=i;S.cur=nextId;S.beat=0;S.visited[nextId]=(S.visited[nextId]||0)+1;if(S.stack[S.stack.length-1]!==n.id)S.stack.push(n.id);save();render();
 }
 function redraw(){
  const m=n.items[i],last=i===n.items.length-1;
  stage.innerHTML='<div class="memory-v15-stage"><section class="memory-v15-shell"><div class="memory-v15-image" role="img" aria-label="'+esc(m.title)+'" style="background-image:url(&quot;'+esc(m.image)+'&quot;)"><span class="memory-v15-number">MEMORY '+String(i+1).padStart(2,'0')+' / '+String(n.items.length).padStart(2,'0')+'</span></div><div class="memory-v15-copy"><div class="memory-v15-kicker">CHAPTER 12 · BEFORE THE ANSWER</div><h2>'+esc(m.title)+'</h2><p class="memory-v15-body">'+esc(m.body)+'</p><div class="memory-v15-pips">'+n.items.map((_,j)=>'<button type="button" class="memory-v15-pip '+(i===j?'on':'')+'" data-memory-v15="'+j+'" aria-label="查看第 '+(j+1)+' 段记忆"></button>').join('')+'</div><div class="memory-v15-actions"><button type="button" class="memory-v15-prev" id="memoryV15Prev" '+(!i?'disabled':'')+'>← 上一段</button><button type="button" class="memory-v15-next" id="memoryV15Next">'+(last?'进入最后的选择 →':'下一段记忆 →')+'</button></div><p class="memory-v15-note">这些画面不会替你作出决定。看完之后，选择仍然属于你。</p></div></section></div>';
  stage.querySelectorAll('[data-memory-v15]').forEach(btn=>btn.onclick=()=>{i=Number(btn.dataset.memoryV15);S.flags.memory_v15_index=i;save();redraw();});
  const prev=stage.querySelector('#memoryV15Prev');if(prev)prev.onclick=()=>{i=Math.max(0,i-1);S.flags.memory_v15_index=i;save();redraw();};
  stage.querySelector('#memoryV15Next').onclick=()=>{if(last){leave();return;}i++;S.flags.memory_v15_index=i;save();redraw();};
  footHint.innerHTML=last?'进入最后的选择　<b>▸</b>':'翻阅下一段记忆　<b>▸</b>';foot.onclick=last?leave:()=>{i++;S.flags.memory_v15_index=i;save();redraw();};
 }
 delete stage.dataset.layout;delete stage.dataset.sceneKey;document.body.dataset.sliceScene='memory-v15';document.body.dataset.scene='bedroom-night';document.body.style.background='';redraw();
}
function renderGallery(n){
 const key='gallery_v16_seen_'+n.id,seen=new Set(S.flags[key]||[]);
 let active=Math.max(0,Math.min(n.items.length-1,Number(S.flags.gallery_v16_active)||0));
 const nextId=n.next;
 function leave(method){
  if(!nextId||!N[nextId]){inform('《冬夜》后续剧情节点缺失');return;}
  S.flags.gallery_completed=seen.size===n.items.length;S.flags.gallery_skipped=false;S.flags.gallery_v16_method=method;S.flags[key]=Array.from(seen);S.cur=nextId;S.beat=0;S.visited[nextId]=(S.visited[nextId]||0)+1;if(S.stack[S.stack.length-1]!==n.id)S.stack.push(n.id);save();render();
 }
 function openPainting(i){active=i;seen.add(i);S.flags.gallery_v16_active=i;S.flags[key]=Array.from(seen);save();redraw();}
 function redraw(){
  const item=n.items[active],next=(active+1)%n.items.length;
  stage.innerHTML='<div class="if-v16-stage"><section class="if-v16-shell"><div class="if-v16-view" role="img" aria-label="'+esc(item.title)+'" style="background-image:url(&quot;'+esc(item.image)+'&quot;)"><span class="if-v16-index">PAINTING '+String(active+1).padStart(2,'0')+' / '+String(n.items.length).padStart(2,'0')+'</span><div class="if-v16-caption"><span>MO ART STUDIO · MEMORY STUDY</span><h3>'+esc(item.title)+'</h3></div></div><div class="if-v16-copy"><div class="if-v16-kicker">IF · WINTER NIGHT</div><h2>'+esc(n.title||'在忘记以前')+'</h2><p class="if-v16-intro">'+esc(n.prompt)+'</p><div class="if-v16-list">'+n.items.map((it,i)=>'<button type="button" class="if-v16-item '+(seen.has(i)?'seen ':'')+(i===active?'active':'')+'" data-if-v16="'+i+'"><span class="if-v16-thumb" style="background-image:url(&quot;'+esc(it.image)+'&quot;)"></span><span><strong>'+esc(it.title)+'</strong><small>'+(seen.has(i)?'已经看过':'触碰画面')+'</small></span></button>').join('')+'</div>'+(item.body?'<p class="if-v16-body">'+esc(item.body)+'</p>':'')+'<div class="if-v16-progress"><span>已看 '+seen.size+' / '+n.items.length+' 幅</span><span>画过的痕迹不会消失</span></div><div class="if-v16-actions"><button type="button" class="if-v16-next" id="ifV16Next">查看下一幅</button><button type="button" class="if-v16-continue" id="ifV16Continue">推开记忆，继续冬夜 →</button></div></div></section></div>';
  stage.querySelectorAll('[data-if-v16]').forEach(btn=>btn.onclick=e=>{e.stopPropagation();openPainting(Number(btn.dataset.ifV16));});
  stage.querySelector('#ifV16Next').onclick=e=>{e.stopPropagation();openPainting(next);};
  stage.querySelector('#ifV16Continue').onclick=e=>{e.stopPropagation();leave('画廊按钮');};
  footHint.innerHTML='继续《冬夜》后续剧情　<b>▸</b>';foot.onclick=()=>leave('底部继续');
 }
 delete stage.dataset.layout;delete stage.dataset.sceneKey;document.body.dataset.sliceScene='if-gallery-v16';document.body.dataset.scene='gallery';document.body.style.background='';openPainting(active);
}
function renderEnding(n){document.body.style.background='';unlockEnding(n.id);stage.innerHTML='<div class="wrap ending-story"><div class="end"><div class="kicker">ANOTHER ENDING</div><h2>'+esc(n.title)+'</h2><div class="mood">'+esc(n.mood||'')+'</div><div class="rule2"></div></div><div class="paras">'+(n.text||[]).map(t=>'<p class="tp">'+esc(t)+'</p>').join('')+'</div><button class="ending-story-enter" id="endingStoryEnter">进入结局画面</button></div>';
 S.autoPlay=false;save();$('#endingStoryEnter').onclick=()=>showEndingPage(n.id);footHint.innerHTML='进入结局画面　<b>▸</b>';foot.onclick=()=>showEndingPage(n.id);}
function showEndingPage(id){
 const item=ENDING_CATALOG.find(entry=>entry.id===id);if(!item){inform('结局页面不存在');return;}
 const imagePosition=item.id==='TRUE_LONGEVITY'?'20% center':'center';
 warmAsset(item.image,'high');
 unlockEnding(item.id);
 if(item.id==='TRUE_LONGEVITY'){S.ifUnlocked=true;S.completedMain=true;}
 save();refreshUnlockUI();
 ovIn.className='in ending-reveal-in';
 ovIn.innerHTML='<article class="ending-reveal"><div class="ending-reveal-visual" role="img" aria-label="'+esc(item.title)+'"><img class="ending-reveal-image" src="'+esc(item.image)+'" alt="" decoding="async" fetchpriority="high" style="object-position:'+imagePosition+'"></div><div class="ending-reveal-shade"></div><div class="ending-reveal-copy"><span class="ending-reveal-type">'+esc(item.type)+'</span><h2>'+esc(item.title)+'</h2><p>'+esc(item.mood)+'</p><div class="ending-reveal-rule"></div><div class="ending-reveal-actions"><button class="pri" id="endingRevealBack">回到上次选择</button><button id="endingRevealHome">返回封面</button><button id="endingRevealArchive">结局图鉴</button><button id="endingRevealRestart">重新开始</button>'+(item.id==='TRUE_LONGEVITY'?'<button id="endingRevealIF">阅读《冬夜》</button>':'')+'</div></div></article>';
 ov.classList.add('on','ending-on');ov.scrollTop=0;
 const endingImage=ovIn.querySelector('.ending-reveal-image');if(endingImage){let retries=0;endingImage.addEventListener('error',()=>{if(retries++<2)setTimeout(()=>{endingImage.src=item.image;},900*retries);});}
 $('#endingRevealBack').onclick=()=>{closeOv();backToChoice();};
 $('#endingRevealHome').onclick=home;
 $('#endingRevealArchive').onclick=()=>{closeOv();openEndings();};
 $('#endingRevealRestart').onclick=()=>restart();
 const ifButton=$('#endingRevealIF');if(ifButton)ifButton.onclick=()=>{closeOv();go('CHIF');};
}

function refreshStart(){
 $('#resumeWrap').style.display=S.started&&N[S.cur]?'block':'none';
 $('#resumeAt').textContent=S.started&&N[S.cur]?(S.cur+' · '+N[S.cur].chapter+'章'):'';
 $('#btnIF').style.display=S.ifUnlocked?'inline-block':'none';
 const mode=$('#btnMode');if(mode)mode.textContent=S.mode==='read'?'视觉':'沉浸';
 refreshUnlockUI();
}
let musicAudio=null,musicReady=false;
function updateMusicButton(){const button=$('#btnMusic');if(!button)return;const muted=!!S.musicMuted;button.textContent=muted?'♪':'♫';button.classList.toggle('muted',muted);button.title=muted?'播放背景音乐':'关闭背景音乐';button.setAttribute('aria-label',button.title);}
function ensureMusic(){
 if(!musicAudio){
  musicAudio=new Audio('assets/audio/background-music.mp3');musicAudio.loop=true;musicAudio.preload='auto';musicAudio.volume=.38;
  musicAudio.addEventListener('canplay',()=>{musicReady=true;if(!S.musicMuted)musicAudio.play().catch(()=>{});},{once:true});
  musicAudio.addEventListener('error',()=>{musicReady=false;const button=$('#btnMusic');if(button){button.disabled=true;button.classList.add('muted');button.textContent='♪';button.title='背景音乐文件尚未加入';button.setAttribute('aria-label',button.title);}});
 }
 updateMusicButton();
 if(!S.musicMuted)musicAudio.play().catch(()=>{});
}
function toggleMusic(){S.musicMuted=!S.musicMuted;updateMusicButton();save();if(S.musicMuted){if(musicAudio)musicAudio.pause();}else ensureMusic();}
function tryAutoplayMusic(){if(S.musicMuted)return;ensureMusic();}
function refreshUnlockUI(){$('#btnContents').style.display='grid';$('#btnContentsStart').style.display='inline-block';}
$('#btnMode').addEventListener('click',function(){S.autoPlay=false;S.mode=S.mode==='read'?'gal':'read';$('#btnMode').textContent=S.mode==='read'?'视觉':'沉浸';render();save();});
$('#btnBack').addEventListener('click',back);
$('#btnHome').addEventListener('click',home);
$('#btnTheme').addEventListener('click',toggleTheme);
$('#btnThemeStart').addEventListener('click',toggleTheme);
$('#btnMusic').addEventListener('click',toggleMusic);
$('#btnContents').addEventListener('click',openContents);
$('#btnContentsStart').addEventListener('click',openContents);
$('#closeContents').addEventListener('click',closeContents);
$('#navScrim').addEventListener('click',closeContents);
$('#btnEndings').addEventListener('click',openEndings);
$('#btnEndingsStart').addEventListener('click',openEndings);
$('#closeEndings').addEventListener('click',closeEndings);
$('#chapterList').addEventListener('click',function(e){const b=e.target.closest('[data-chapter-id]');if(!b||b.disabled)return;const id=b.dataset.chapterId;if(!N[id])return;ensureMusic();closeContents();$('#start').style.display='none';S.started=true;S.stack=[];go(id,false);});
$('#endingGrid').addEventListener('click',function(e){const b=e.target.closest('[data-ending-id]');if(!b||b.disabled)return;const id=b.dataset.endingId;closeEndings();showEndingPage(id);});
ov.addEventListener('click',function(e){const b=e.target.closest('[data-continue-node]');if(!b||b.disabled)return;const id=b.dataset.continueNode||S.flags.pending_next;if(!id||!N[id]){inform('后续剧情节点缺失');return;}b.disabled=true;delete S.flags.pending_next;save();closeOv();go(id);});
var sizes=[-2,-1,0,1,2];
$('#btnText').addEventListener('click',function(){var idx=sizes.indexOf(Number(S.textSize));S.textSize=sizes[(idx+1)%sizes.length];applyTextSize();save();inform({'-2':'极小字号','-1':'较小字号','0':'默认字号','1':'较大字号','2':'最大字号'}[String(S.textSize)]);});
Array.prototype.forEach.call(document.querySelectorAll('#start .modes button'),function(btn){btn.addEventListener('click',function(){ensureMusic();restart(btn.getAttribute('data-mode'));});});
$('#btnResume').addEventListener('click',function(){if(!S.started||!N[S.cur])return;ensureMusic();$('#start').style.display='none';render();});
$('#btnIF').addEventListener('click',function(){ensureMusic();$('#start').style.display='none';S.started=true;go('CHIF');});
stage.addEventListener('click',function(e){var n=N[S.cur];const galleryNext=e.target.closest('[data-gallery-next]');if(galleryNext&&!galleryNext.disabled){const id=galleryNext.dataset.galleryNext;if(id&&N[id]){galleryNext.disabled=true;S.flags.gallery_completed=galleryNext.dataset.galleryResult==='complete';S.flags.gallery_skipped=galleryNext.dataset.galleryResult==='skip';save();go(id);}else inform('IF 后续剧情节点缺失');return;}const gameNext=e.target.closest('[data-game-next]');if(gameNext&&!gameNext.disabled){const id=gameNext.dataset.gameNext,result=gameNext.dataset.gameResult||'';if(!id||!N[id]){inform('玩法后续剧情节点缺失');return;}gameNext.disabled=true;if(result==='dance-skip')S.flags.dance_completed=false;else if(result==='dance-complete')S.flags.dance_completed=true;else if(result==='memory-complete')S.flags.memories_read=true;save();go(id);return;}if(n&&n.type==='gallery'){const paint=e.target.closest('[data-paint]');if(paint){const key='gallery_seen_'+n.id,seen=new Set(S.flags[key]||[]);seen.add(Number(paint.dataset.paint));S.flags[key]=Array.from(seen);save();renderGallery(n);return;}}if(e.target.closest('button,input,textarea,select,a'))return;if(!n||n.type!=='page')return;if(S.mode==='read'&&stage.scrollHeight-stage.scrollTop-stage.clientHeight>20)return;advancePage(n);});
document.addEventListener('keydown',function(e){if(e.key==='Escape'){if($('#endingArchive').classList.contains('on')){closeEndings();return;}if($('#chapterDrawer').classList.contains('on')){closeContents();return;}}if(ov.classList.contains('on')||$('#start').style.display!=='none'||e.target.closest('input,textarea,select,button'))return;var n=N[S.cur];if(!n)return;if([' ','Enter','ArrowRight','ArrowDown'].indexOf(e.key)!==-1){if(n.type==='page'){e.preventDefault();advancePage(n);}else if(n.type==='chapter'){e.preventDefault();go(n.next);}}else if(e.key==='ArrowLeft'){e.preventDefault();back();}else if(e.key==='Escape')home();});
// Load preferred container storage if the platform injects its SDK.
// Local storage remains a best-effort fallback; neither can be assumed permanent.
var bridge=window.xhs&&window.xhs.miniTool,storageLoad=null;
if(bridge&&typeof bridge.getStorage==='function'){
 try{
  storageLoad=Promise.resolve(bridge.getStorage({key:SAVEKEY})).then(function(res){
    if(!res||!res.data||$('#start').style.display==='none')return;
    var candidate=JSON.parse(res.data);
    if(candidate&&N[candidate.cur]&&candidate.started){S=Object.assign(fresh(),candidate);if(S.ifUnlocked)S.completedMain=true;if(!S.endings||typeof S.endings!=='object')S.endings={};if([-2,-1,0,1,2].indexOf(Number(S.textSize))===-1)S.textSize=0;else S.textSize=Number(S.textSize);applyTheme();applyTextSize();refreshStart();}
  }).catch(function(){});
 }catch(e){}
}
applyTheme();
applyTextSize();
updateMusicButton();
refreshStart();
startBackgroundWarmup();
tryAutoplayMusic();
document.addEventListener('pointerdown',function resumeMusicOnce(){if(!S.musicMuted)ensureMusic();document.removeEventListener('pointerdown',resumeMusicOnce);},{once:true});
if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol)){navigator.serviceWorker.register('./service-worker.js').catch(function(){});}
window.__INVALID_MARK_TEST__={getState:function(){return JSON.parse(JSON.stringify(S));},getStory:function(){return D;},go:function(id){$('#start').style.display='none';S.started=true;go(id,false);},setState:function(next){S=Object.assign(fresh(),S,next||{});applyTheme();applyTextSize();refreshStart();render();save();},home:home,openContents:openContents,openEndings:openEndings};
})();
